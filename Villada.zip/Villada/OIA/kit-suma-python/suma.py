def suma(v):
    # Aqui se debe implementar la solucion
     total = 0

     for i in v:
         total += i

     return total