import suma

def main():
    n = int(input())
    ns = [int(input()) for _ in range(n)]
    print(suma.suma(ns))

if __name__ == "__main__":
    main()
