t = 34, 34 , 44, 45
print(len(t))
print(t[len(t) - 1])