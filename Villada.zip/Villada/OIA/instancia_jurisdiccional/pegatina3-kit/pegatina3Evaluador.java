import java.io.*;
import java.lang.*;
import java.util.*;

public class pegatina3Evaluador {
    private static String nextLine = "";
    private static int nextIndex = 0;
    private static BufferedReader reader;
    
    private static String readToken() throws IOException {
        while (true) {
            while (nextIndex < nextLine.length() && nextLine.charAt(nextIndex) == ' ') nextIndex++;
            if (nextIndex == nextLine.length()) {
                nextLine = reader.readLine();
                nextIndex = 0;
            } else {
                break;
            }
        }
        int baseIndex = nextIndex++;
        while (nextIndex < nextLine.length() && nextLine.charAt(nextIndex) != ' ') nextIndex++;
        return nextLine.substring(baseIndex, nextIndex);
    }
    
    public static void main(String [] args) throws IOException {
        reader = new BufferedReader(new InputStreamReader(System.in));
        try (PrintWriter writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)))) {
            int N;
            N = Integer.parseInt(readToken());
            int K;
            K = Integer.parseInt(readToken());
            String returnedValue;
            returnedValue = pegatina3.pegatina(N, K);
            writer.println(returnedValue);
        }
    }
}
