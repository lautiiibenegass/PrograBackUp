#include <iostream>
#include <string>
#include <vector>

using namespace std;

string pegatina(int N, int K);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int N;
    cin >> N;
    int K;
    cin >> K;
    string returnedValue;
    returnedValue = pegatina(N, K);
    cout << returnedValue << "\n";
    return 0;
}
