#include <string>
#include <vector>

using namespace std;

string pegatina(int N, int K) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
