import java.lang.*;
import java.util.*;

public class pegatina3 {
    public static String pegatina(int N, int K) {
        // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
    }
}
