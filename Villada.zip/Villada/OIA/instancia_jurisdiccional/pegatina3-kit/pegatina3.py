def pegatina(N, K):
    # AQUI SE DEBE IMPLEMENTAR LA SOLUCION
    numeros = []
    num = 0
    strnum = ''
    while num <= N:
        for i in numeros:
            num += 1
            numeros.append(num)
            if i % K ==0:
                j = str(i)
            strnum = strnum + j
    return strnum

pegatina(29, 7)
