def petitorios(T, jefes):
    # AQUI SE DEBE IMPLEMENTAR LA SOLUCION
    jefes = []
    for i in jefes:
        minEmpleados = int(jefes[i] / (T/100))
    return minEmpleados