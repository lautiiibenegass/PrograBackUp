#include <iostream>
#include <string>
#include <vector>

using namespace std;

int petitorios(int T, vector<int> &jefes);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int N;
    cin >> N;
    int T;
    cin >> T;
    vector<int> jefes;
    jefes.resize(N);
    for (int i0 = 0; i0 < N; i0++) {
        cin >> jefes[i0];
    }
    int returnedValue;
    returnedValue = petitorios(T, jefes);
    cout << returnedValue << "\n";
    return 0;
}
