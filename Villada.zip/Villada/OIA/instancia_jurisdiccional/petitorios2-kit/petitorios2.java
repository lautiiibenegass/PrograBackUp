import java.lang.*;
import java.util.*;

public class petitorios2 {
    public static int petitorios(int T, ArrayList<Integer> jefes) {
        // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
    }
}
