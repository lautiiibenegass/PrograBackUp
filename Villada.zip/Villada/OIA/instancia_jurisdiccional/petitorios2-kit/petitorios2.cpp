#include <string>
#include <vector>

using namespace std;

int petitorios(int T, vector<int> &jefes) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
