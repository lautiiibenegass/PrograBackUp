import sys
import petitorios2

allTokens = iter(sys.stdin.read().split())
def readToken():
    return next(allTokens)

def main():
    N = int(readToken());
    T = int(readToken());
    jefes = [None]*(N)
    for i0 in range(N):
        jefes[i0] = int(readToken());
    returnedValue = petitorios2.petitorios(T, jefes);
    print(returnedValue)


if __name__ == "__main__":
    main()

