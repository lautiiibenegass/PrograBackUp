import sys
import millas3

allTokens = iter(sys.stdin.read().split())
def readToken():
    return next(allTokens)

def main():
    N = int(readToken());
    M = int(readToken());
    a = [None]*(M)
    b = [None]*(M)
    d = [None]*(M)
    m = [None]*(M)
    for i in range(M):
        a[i] = int(readToken());
        b[i] = int(readToken());
        d[i] = int(readToken());
        m[i] = int(readToken());
    returnedValue = millas3.millas(N, a,b,d,m);
    for i in range(len(returnedValue)):
        if i > 0: print(" ",end="");
        print(returnedValue[i], end="")
    print();


if __name__ == "__main__":
    main()

