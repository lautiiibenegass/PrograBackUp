def millas(N, a, b, d, m):
    # AQUI SE DEBE IMPLEMENTAR LA SOLUCION
    return
