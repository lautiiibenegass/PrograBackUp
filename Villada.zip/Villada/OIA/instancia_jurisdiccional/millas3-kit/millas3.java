import java.lang.*;
import java.util.*;

public class millas3 {
    public static ArrayList<Long> millas(int N, ArrayList<Integer> a, ArrayList<Integer> b, ArrayList<Integer> d, ArrayList<Integer> m) {
        // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
    }
}
