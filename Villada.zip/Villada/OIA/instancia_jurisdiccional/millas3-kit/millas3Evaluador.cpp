#include <iostream>
#include <string>
#include <vector>

using namespace std;

vector<long long> millas(int N, vector<int> &a, vector<int> &b, vector<int> &d, vector<int> &m);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int N;
    cin >> N;
    int M;
    cin >> M;
    vector<int> a;
    vector<int> b;
    vector<int> d;
    vector<int> m;
    a.resize(M);
    b.resize(M);
    d.resize(M);
    m.resize(M);
    for (int i = 0; i < M; i++) {
        cin >> a[i];
        cin >> b[i];
        cin >> d[i];
        cin >> m[i];
    }
    vector<long long> returnedValue;
    returnedValue = millas(N, a,b,d,m);
    for (int i = 0; i < int(returnedValue.size()); i++) {
        if (i > 0) cout << " ";
        cout << returnedValue[i];
    }
    cout << "\n";
    return 0;
}
