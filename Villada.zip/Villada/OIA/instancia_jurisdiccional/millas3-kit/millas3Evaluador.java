import java.io.*;
import java.lang.*;
import java.util.*;

public class millas3Evaluador {
    private static String nextLine = "";
    private static int nextIndex = 0;
    private static BufferedReader reader;
    
    private static String readToken() throws IOException {
        while (true) {
            while (nextIndex < nextLine.length() && nextLine.charAt(nextIndex) == ' ') nextIndex++;
            if (nextIndex == nextLine.length()) {
                nextLine = reader.readLine();
                nextIndex = 0;
            } else {
                break;
            }
        }
        int baseIndex = nextIndex++;
        while (nextIndex < nextLine.length() && nextLine.charAt(nextIndex) != ' ') nextIndex++;
        return nextLine.substring(baseIndex, nextIndex);
    }
    
    public static void main(String [] args) throws IOException {
        reader = new BufferedReader(new InputStreamReader(System.in));
        try (PrintWriter writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)))) {
            int N;
            N = Integer.parseInt(readToken());
            int M;
            M = Integer.parseInt(readToken());
            ArrayList<Integer> a;
            ArrayList<Integer> b;
            ArrayList<Integer> d;
            ArrayList<Integer> m;
            a = new ArrayList<>(M);
            b = new ArrayList<>(M);
            d = new ArrayList<>(M);
            m = new ArrayList<>(M);
            for (int i = 0; i < M; i++) {
                int aux_a;
                aux_a = Integer.parseInt(readToken());
                a.add(aux_a);
                int aux_b;
                aux_b = Integer.parseInt(readToken());
                b.add(aux_b);
                int aux_d;
                aux_d = Integer.parseInt(readToken());
                d.add(aux_d);
                int aux_m;
                aux_m = Integer.parseInt(readToken());
                m.add(aux_m);
            }
            ArrayList<Long> returnedValue;
            returnedValue = millas3.millas(N, a,b,d,m);
            for (int i = 0; i < returnedValue.size(); i++) {
                if (i > 0) writer.print(" ");
                writer.print(returnedValue.get(i));
            }
            writer.println();
        }
    }
}
