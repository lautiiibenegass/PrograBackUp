#include <string>
#include <vector>

using namespace std;

vector<long long> millas(int N, vector<int> &a, vector<int> &b, vector<int> &d, vector<int> &m) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
