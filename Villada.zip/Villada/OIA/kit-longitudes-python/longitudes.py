def dameLongitudes(v):
    # Aqui se debe implementar la solucion
    list = []
    for i in v:
        list.append(len(i))
    return list
