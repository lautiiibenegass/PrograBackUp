import longitudes

def main():
    n = int(input())
    ns = [input() for _ in range(n)]
    print(" ".join(map(str, longitudes.dameLongitudes(ns))))

if __name__ == "__main__":
    main()
