def filtranum(numeros, resultado):
    # Aqui se debe implementar la solucion
    num = []
    for i in numeros:
        stnum = str(i)
        if stnum[0] == stnum[-1]:
            num.append(i)
    resultado[:] = num
    return len(num)
