import filtranum

def main():
    n = int(input())
    ns = list(map(int, input().split()))
    resultado = []
    print(filtranum.filtranum(ns, resultado))
    print(" ".join(map(str, resultado)))

if __name__ == "__main__":
    main()
