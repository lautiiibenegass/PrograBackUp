CREATE DATABASE IF NOT EXISTS base_peliculas;


USE base_peliculas;



CREATE TABLE IF NOT EXISTS peliculas(
	id_pelicula INT NOT NULL,
    titulo VARCHAR(45) NOT NULL,
    anio DATE,
    nacionalidad VARCHAR(20),
    idioma VARCHAR(120),
    formato ENUM('blanco y negro', 'color'),
    descripcion VARCHAR(120),
    resumen VARCHAR(255),
    observaciones VARCHAR(255),
    primary key(id_pelicula)
)ENGINE=INNODB;



CREATE TABLE IF NOT EXISTS actores(
	id_actor INT NOT NULL,
    nombre VARCHAR(45) NOT NULL,
    nacionalidad VARCHAR(45),
    nombre_personaje VARCHAR(45),
    primary key(id_actor)
    )ENGINE=INNODB;
    
  
    
CREATE TABLE IF NOT EXISTS directores(
	id_director INT NOT NULL,
    nombre VARCHAR(120) NOT NULL,
    fecha_nacimiento DATE,
    pais_origen VARCHAR(120),
    primary key(id_director),
    peliculas_id_pelicula INT NOT NULL,
    constraint fkdirector_peliculas
    FOREIGN KEY(peliculas_id_pelicula)
    references peliculas(id_pelicula)
    )ENGINE=INNODB;
    
    

CREATE TABLE IF NOT EXISTS actores_peliculas(
	peliculas_id_pelicula INT NOT NULL,
    actores_id_actor INT NOT NULL,
    primary key(peliculas_id_pelicula, actores_id_actor),
    constraint fkactor_peliculas_actor
    FOREIGN KEY(actores_id_actor)
    references actores(id_actor),
    constraint fkactor_actor_pelicula
    FOREIGN KEY(peliculas_id_pelicula)
    references peliculas(id_pelicula)
    )ENGINE=INNODB;

INSERT INTO peliculas (id_pelicula, titulo, anio, nacionalidad, idioma, formato, descripcion, resumen) VALUES
(200, 'Son como niños', '2010-01-01', 'EE UU', 'Inglés', 'color', 'Utiliza la parodia del cascanueces', 'Un grupo de amigos y excompañeros de escuela se reencuentran'),
(201, 'El secreto de sus ojos', '2009-01-01', 'Argentina', 'Castellano', 'color', 'Un género policial apasionante', 'Un banquero busca encontrar al asesino de su hija'),
(202, 'El robo del siglo', '2020-01-01', 'Argentina', 'Castellano', 'color', 'Un dramático y apasionante relato policial', 'Un robo que marcó para siempre a los argentinos'),
(203, 'La odisea de los giles', '2019-01-01', 'Argentina', 'Castellano', 'color', 'Le roban a un abogado reconocido', 'Un grupo de personas le roban a un abogado reconocido'),
(204, 'Duro de Matar', '1988-01-01', 'EE UU', 'Inglés', 'color', 'Un agente debe ser asesinado', 'Un tráiler interesante para los amantes del cine de acción'),
(205, '50 First Dates', '2004-01-01', 'EE UU', 'Inglés', 'color', 'Comedia romántica', 'Henry Roth, quien intenta ganar el corazón de Lucy'),
(206, 'G.I. Joe', '2021-07-23', 'EE UU', 'Inglés', 'color', 'Un guerrero ninja lucha con su pasado', 'El icónico personaje de G.I. Joe aprende a dominar su destino');


INSERT INTO actores (id_actor, nombre, nacionalidad, nombre_personaje) VALUES
(101, 'Bruce Willis', 'EE UU', 'John McClane'),
(102, 'Adam Sandler', 'EE UU', 'Cubo'),
(103, 'Chan Kong-sang', 'Hongkonesa', 'Jackie Chan'),
(104, 'Guillermo Francella', 'Argentino', 'Pepe'),
(105, 'Úrsula Cordero', 'Española', 'Tokio'),
(106, 'Luis Brandoni', 'Argentino', 'Pelado'),
(107, 'Ricardo Darín', 'Argentino', 'Chino'),
(108, 'Alan Rickman', 'EE UU', 'Villano'),
(109, 'Drew Barrymore', 'EE UU', 'Pita'),
(110, 'Chris Rock', 'EE UU', 'Jack'),
(111, 'Andrew Koji', 'Inglés', 'Snake');

INSERT INTO directores (id_director, nombre, fecha_nacimiento, pais_origen, peliculas_id_pelicula) VALUES
(300, 'Sebastián Borensztein', '1963-04-22', 'Argentina', 203),
(301, 'Juan Campanela', '1959-07-19', 'Argentina', 201),
(302, 'Denis Dugan', '1946-09-05', 'Estados Unidos', 200),
(303, 'Ariel Winograd', '1977-08-23', 'Argentina', 202),
(304, 'John Moore', '1970-04-27', 'Irlanda', 204),
(305, 'Peter Segal', '1962-04-20', 'Estados Unidos', 205),
(306, 'Robert Schwentke', '1968-02-18', 'Alemania', 206);

INSERT INTO actores_peliculas (peliculas_id_pelicula, actores_id_actor) VALUES
(200, 102),
(201, 104),
(201, 107),
(202, 104),
(203, 106),
(203, 107),
(204, 101),
(204, 108),
(205, 102),
(205, 109);


select actores.nombre, peliculas.titulo
from actores_peliculas
inner join actores on actores_peliculas.actores_id_actor=actores.id_actor
inner join peliculas on actores_peliculas.peliculas_id_pelicula=peliculas.id_pelicula
where peliculas.titulo='El secreto de sus ojos'