create database if not exists base_peliculas;
use base_peliculas;

create table if not exists peliculas(
    id_pelicula int not null,
    titulo varchar(45) not null,
    anio date,
    nacionalidad varchar(120),
    idioma varchar(120),
    formato enum('blanco y negro', 'color'),
    descripcion varchar(120),
    resumen varchar(255),
    observaciones varchar(255)
);

create table if not exists actores(
    id_actor int not null,
    nombre varchar(45) not null,
    nacionalidad varchar(45),
    nombre_personaje varchar(45)
);

create table if not exists directores(
    id_director int not null,
    nombre varchar(45) not null,
    fecha_nacimiento date,
    pais_origen varchar(45)
);

describe actores;

alter table actores
    add column signo varchar(45);

describe actores;

alter table actores
    drop column signo;

describe actores;

alter table actores
    drop column nacionalidad;

describe actores;

truncate actores;

describe actores;

select * from actores;

truncate actores;

describe actores;
