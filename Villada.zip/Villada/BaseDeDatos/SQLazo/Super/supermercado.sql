CREATE DATABASE IF NOT EXISTS Base_Super;

USE Base_Super;

CREATE TABLE IF NOT EXISTS Sucursal (
    id_sucursal INT NOT NULL,
    nombre VARCHAR(45) NOT NULL,
    numero INT,
    cuit INT,
    cond_iva INT,
    direccion VARCHAR(255),
    PRIMARY KEY (id_sucursal)
) ENGINE=INNODB;

CREATE TABLE IF NOT EXISTS Cajero (
    id_cajero INT NOT NULL,
    nombre VARCHAR(45) NOT NULL,
    apellido VARCHAR(45) NOT NULL,
    numero_calle INT,
    cod_postal INT,
    id_turno INT,
    turno ENUM('mañana', 'tarde', 'noche') NOT NULL,
    PRIMARY KEY (id_cajero)
) ENGINE=INNODB;

CREATE TABLE IF NOT EXISTS Domicilio (
    id_domicilio INT NOT NULL,
    calle VARCHAR(45) NOT NULL,
    numero_calle INT,
    cod_postal INT,
    id_sucursal INT,
    id_cajero INT,
    PRIMARY KEY (id_domicilio),
    CONSTRAINT fksucursal_domicilio FOREIGN KEY (id_sucursal) REFERENCES sucursal(id_sucursal),
    CONSTRAINT fkcajero_domicilio FOREIGN KEY (id_cajero) REFERENCES cajero(id_cajero)
) ENGINE=INNODB;

CREATE TABLE IF NOT EXISTS Caja (
    id_caja INT NOT NULL,
    estado ENUM('abierta', 'cerrada') NOT NULL,
    PRIMARY KEY (id_caja)
) ENGINE=INNODB;

-- Tabla Asignacion
CREATE TABLE IF NOT EXISTS Asignacion (
    id_asignacion INT NOT NULL,
    id_caja INT,
    id_cajero INT,
    PRIMARY KEY (id_asignacion),
    CONSTRAINT fk_asignacion_caja FOREIGN KEY (id_caja) REFERENCES caja(id_caja),
    CONSTRAINT fk_asignacion_cajero FOREIGN KEY (id_cajero) REFERENCES cajero(id_cajero)
) ENGINE=INNODB;

CREATE TABLE IF NOT EXISTS Venta (
    id_venta INT NOT NULL,
    fecha_hora_compra DATETIME,
    id_asignacion INT,
    PRIMARY KEY (id_venta),
    CONSTRAINT fk_venta_asignacion FOREIGN KEY (id_asignacion) REFERENCES asignacion(id_asignacion)
) ENGINE=INNODB;

CREATE TABLE IF NOT EXISTS Articulo (
    id_articulo INT NOT NULL,
    precio_unitario FLOAT,
    stock INT,
    PRIMARY KEY (id_articulo)
) ENGINE=INNODB;

CREATE TABLE IF NOT EXISTS Detalle (
    id_detalle INT NOT NULL,
    id_venta INT,
    id_articulo INT,
    cantidad INT NOT NULL,
    PRIMARY KEY (id_detalle),
    CONSTRAINT fk_detalle_venta FOREIGN KEY (id_venta) REFERENCES venta(id_venta),
    CONSTRAINT fk_detalle_articulo FOREIGN KEY (id_articulo) REFERENCES articulo(id_articulo)
) ENGINE=INNODB;