CREATE DATABASE IF NOT EXISTS Cripto_Sim;
USE Cripto_Sim;


CREATE TABLE Pais (
    nombre VARCHAR(100) PRIMARY KEY,
    descripcion VARCHAR(255)
);

CREATE TABLE Ciudad (
    codCiudad INT PRIMARY KEY,
    nombre VARCHAR(100),
    pais VARCHAR(100),
    descripcion VARCHAR(255),
    FOREIGN KEY (pais) REFERENCES Pais(nombre)
);

CREATE TABLE TipoTelefono (
    tipo VARCHAR(50) PRIMARY KEY,
    descripcion VARCHAR(255)
);

CREATE TABLE TipoDocumento (
    tipo VARCHAR(50) PRIMARY KEY,
    descripcion VARCHAR(255)
);

CREATE TABLE Ejecutivo (
    legajo INT PRIMARY KEY,
    nombres VARCHAR(100),
    apellido VARCHAR(100),
    numDoc INT,
    tipoDoc VARCHAR(50),
    FOREIGN KEY (tipoDoc) REFERENCES TipoDocumento(tipo)
);

CREATE TABLE Cliente (
    numCliente INT PRIMARY KEY,
    apellido VARCHAR(100),
    nombre VARCHAR(100),
    email VARCHAR(100),
    telefono VARCHAR(20),
    tipoTelefono VARCHAR(50),
    ciudadResidencia INT,
    paisResidencia VARCHAR(100),
    fechaAlta DATE,
    FOREIGN KEY (tipoTelefono) REFERENCES TipoTelefono(tipo),
    FOREIGN KEY (ciudadResidencia) REFERENCES Ciudad(codCiudad),
    FOREIGN KEY (paisResidencia) REFERENCES Pais(nombre)
);

CREATE TABLE Criptomoneda (
    cod3Letras VARCHAR(3) PRIMARY KEY,
    nombre VARCHAR(100),
    histCotizaciones INT
);

CREATE TABLE Cotizacion (
    idCotizacion INT PRIMARY KEY,
    valorDolares INT,
    dia DATE,
    hora TIME
);

CREATE TABLE HistorialCotizaciones (
    codigohist INT PRIMARY KEY,
    Criptomoneda VARCHAR(3),
    cotizacion INT,
    descripcion VARCHAR(255),
    FOREIGN KEY (Criptomoneda) REFERENCES Criptomoneda(cod3Letras),
    FOREIGN KEY (cotizacion) REFERENCES Cotizacion(idCotizacion)
);

CREATE TABLE Monedero (
    idMonedero INT PRIMARY KEY,
    cantCriptos INT,
    Criptomoneda VARCHAR(3),
    Cliente INT,
    FOREIGN KEY (Criptomoneda) REFERENCES Criptomoneda(cod3Letras),
    FOREIGN KEY (Cliente) REFERENCES Cliente(numCliente)
);

CREATE TABLE Transaccion (
    numTransaccion INT,
    Cliente INT,
    fechaTransaccion DATE,
    ejecutivo INT,
    PRIMARY KEY (numTransaccion, Cliente),
    FOREIGN KEY (Cliente) REFERENCES Cliente(numCliente),
    FOREIGN KEY (ejecutivo) REFERENCES Ejecutivo(legajo)
);


INSERT INTO Cliente (numCliente, apellido, nombre, email, telefono, tipoTelefono, ciudadResidencia, paisResidencia, fechaAlta) VALUES 
(4, 'Martinez', 'Pedro', 'pedro.martinez@example.com', '4455667788', 'Celular', 1, 'Argentina', '2023-06-10'),
(5, 'Gomez', 'Laura', 'laura.gomez@example.com', '5566778899', 'Celular', 2, 'Brasil', '2023-07-15'),
(6, 'Smith', 'Alice', 'alice.smith@example.com', '6677889900', 'Fijo', 3, 'Estados Unidos', '2023-05-20');

INSERT INTO Monedero (idMonedero, cantCriptos, Criptomoneda, Cliente) VALUES 
(4, 0.3, 'BTC', 4),
(5, 0.8, 'ETH', 4),
(6, 0.5, 'LTC', 4),
(7, 1.0, 'BTC', 5),
(8, 2.0, 'ETH', 5),
(9, 1.5, 'LTC', 5),
(10, 3.0, 'BTC', 6),
(11, 1.0, 'ETH', 6),
(12, 1.2, 'LTC', 6);

INSERT INTO Transaccion (numTransaccion, Cliente, fechaTransaccion, ejecutivo) VALUES 
(4, 4, '2023-08-10', 1001),
(5, 4, '2023-08-12', 1001),
(6, 4, '2023-08-14', 1002),
(7, 5, '2023-08-10', 1002),
(8, 5, '2023-08-12', 1001),
(9, 5, '2023-08-14', 1002),
(10, 6, '2023-08-11', 1001),
(11, 6, '2023-08-13', 1002),
(12, 6, '2023-08-15', 1001);

INSERT INTO Cotizacion (idCotizacion, valorDolares, dia, hora) VALUES 
(4, 31000, '2023-08-10', '12:00:00'),
(5, 2100, '2023-08-11', '12:00:00'),
(6, 160, '2023-08-12', '12:00:00');

INSERT INTO Criptomoneda (cod3Letras, nombre, histCotizaciones) VALUES 
('USD', 'USD Coin', 4),
('ARS', 'Argentine Peso', 5);

SELECT Cliente.numCliente, Cliente.nombre, Cliente.apellido, Cliente.paisResidencia
FROM Cliente
JOIN Monedero ON Cliente.numCliente = Monedero.Cliente
WHERE Cliente.paisResidencia REGEXP '[AEIOUaeiou]'
GROUP BY Cliente.numCliente
HAVING COUNT(Monedero.idMonedero) > 2
AND MONTH(Cliente.fechaAlta) BETWEEN 5 AND 8;



SELECT Criptomoneda.nombre AS Moneda, 
       COUNT(Transaccion.numTransaccion) AS CantidadMovimientos, 
       SUM(Monedero.cantCriptos * Cotizacion.valorDolares) AS CantidadDolaresEnMovilizacion, 
       MAX(Cotizacion.valorDolares) AS MontoMaximoTransaccion, 
       MIN(Cotizacion.valorDolares) AS MontoMinimoTransaccion
FROM Transaccion
JOIN Monedero ON Transaccion.Cliente = Monedero.Cliente
JOIN Criptomoneda ON Monedero.Criptomoneda = Criptomoneda.cod3Letras
JOIN Cotizacion ON Criptomoneda.cod3Letras = Cotizacion.idCotizacion
WHERE MONTH(Transaccion.fechaTransaccion) = MONTH(CURRENT_DATE())
GROUP BY Criptomoneda.cod3Letras
HAVING COUNT(Transaccion.numTransaccion) > 2;



UPDATE Cotizacion
SET valorDolares = valorDolares * 1000, 
    dia = CURDATE()
WHERE idCotizacion IN (SELECT idCotizacion FROM Criptomoneda WHERE cod3Letras IN ('BTC', 'ETH', 'LTC'))
AND Criptomoneda.cod3Letras NOT LIKE 'USD%' 
AND Criptomoneda.cod3Letras NOT LIKE 'ARS%';