create database if not exists Simulacro_Cripto;
use Simulacro_Cripto;
-- Crear base de datos
CREATE DATABASE IF NOT EXISTS Simulacro_Cripto;
USE Simulacro_Cripto;

-- Crear tabla tipoDocumento
CREATE TABLE tipoDocumento (
    tipo VARCHAR(30) PRIMARY KEY,
    descripcion VARCHAR(30)
);

-- Crear tabla ejecutivo
CREATE TABLE ejecutivo (
    legajo INT UNSIGNED AUTO_INCREMENT,
    nombre VARCHAR(30),
    apellido VARCHAR(30),
    numDocumento INT,
    tipo VARCHAR(30),
    legajoCoordinador INT UNSIGNED,
    PRIMARY KEY (legajo),
    INDEX idx_legajoCoordinador (legajoCoordinador)
);

-- Crear tabla cliente
CREATE TABLE cliente (
    numCliente INT UNSIGNED AUTO_INCREMENT,
    apellido VARCHAR(30),
    nombre VARCHAR(30),
    email VARCHAR(30),
    telefono VARCHAR(11),
    fechaAlta DATE,
    tipo VARCHAR(30),
    codCiudad INT UNSIGNED,
    paisNombre VARCHAR(30),
    legajoEjecutivo INT UNSIGNED,
    tipoTelefono VARCHAR(30),
    PRIMARY KEY (numCliente)
);

-- Crear tabla pais
CREATE TABLE pais (
    nombre VARCHAR(30) PRIMARY KEY,
    descripcion VARCHAR(30)
);

-- Crear tabla ciudad
CREATE TABLE ciudad (
    codCiudad INT UNSIGNED AUTO_INCREMENT,
    nombre VARCHAR(30),
    descripcion VARCHAR(30),
    paisNombre VARCHAR(30),
    PRIMARY KEY (codCiudad),
    INDEX idx_paisNombre (paisNombre)
);

-- Crear tabla tipoTelefono
CREATE TABLE tipoTelefono (
    tipo VARCHAR(30) PRIMARY KEY,
    descripcion VARCHAR(30)
);

-- Crear tabla criptomoneda
CREATE TABLE criptomoneda (
    codigo VARCHAR(3) PRIMARY KEY,
    nombre VARCHAR(30),
    codigoHist INT UNSIGNED
);

-- Crear tabla historialCotizacion
CREATE TABLE historialCotizacion (
    codigoHist INT UNSIGNED AUTO_INCREMENT,
    descripcion VARCHAR(30),
    PRIMARY KEY (codigoHist)
);

-- Crear tabla cotizacion
CREATE TABLE cotizacion (
    idCotizacion INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    dia DATE,
    hora TIME,
    codigoHist INT UNSIGNED
);

-- Crear tabla monedero
CREATE TABLE monedero (
    idMonedero INT PRIMARY KEY,
    cantCriptos INT,
    Criptomoneda VARCHAR(3),
    Cliente INT UNSIGNED
);

-- Crear tabla transaccion
CREATE TABLE transaccion (
    numTransaccion INT,
    Cliente INT UNSIGNED,
    fechaTransaccion DATE,
    ejecutivo INT UNSIGNED,
    idMonedero INT UNSIGNED,
    codigoCripto VARCHAR(3),
    monto DECIMAL(20,2),
    PRIMARY KEY (numTransaccion, Cliente)
);

-- Añadir índices a las tablas para claves externas
ALTER TABLE criptomoneda
ADD INDEX idx_codigoHist (codigoHist);

ALTER TABLE ciudad
ADD INDEX idx_paisNombre (paisNombre);

ALTER TABLE monedero
ADD INDEX idx_cliente (Cliente);

ALTER TABLE transaccion
ADD INDEX idx_idMonedero (idMonedero),
ADD INDEX idx_codigoCripto (codigoCripto);

-- Añadir claves externas
ALTER TABLE ejecutivo
ADD CONSTRAINT fk_tipoDocumento FOREIGN KEY (tipo) REFERENCES tipoDocumento(tipo),
ADD CONSTRAINT fk_coordinador FOREIGN KEY (legajoCoordinador) REFERENCES ejecutivo(legajo);

ALTER TABLE cliente
ADD CONSTRAINT fk_legajoEjecutivo FOREIGN KEY (legajoEjecutivo) REFERENCES ejecutivo(legajo),
ADD CONSTRAINT fk_tipoTelefono FOREIGN KEY (tipoTelefono) REFERENCES tipoTelefono(tipo),
ADD CONSTRAINT fk_pais FOREIGN KEY (paisNombre) REFERENCES pais(nombre);

ALTER TABLE monedero
ADD CONSTRAINT fk_cliente FOREIGN KEY (Cliente) REFERENCES cliente(numCliente),
ADD CONSTRAINT fk_criptomoneda FOREIGN KEY (Criptomoneda) REFERENCES criptomoneda(codigo);

ALTER TABLE transaccion
ADD CONSTRAINT fk_transaccion_monedero FOREIGN KEY (idMonedero) REFERENCES monedero(idMonedero),
ADD CONSTRAINT fk_transaccion_cripto FOREIGN KEY (codigoCripto) REFERENCES criptomoneda(codigo);

ALTER TABLE cotizacion
ADD CONSTRAINT fk_cotizacion_historial FOREIGN KEY (codigoHist) REFERENCES historialCotizacion(codigoHist);
