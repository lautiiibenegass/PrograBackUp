CREATE DATABASE IF NOT EXISTS Criadero_Perros;
USE Criadero_Perros;

CREATE TABLE IF NOT EXISTS Pais (
    nombre VARCHAR(100),
    continente VARCHAR(100),
    capital VARCHAR(100),
    PRIMARY KEY(nombre)
);

CREATE TABLE IF NOT EXISTS Ciudad (
    codPostal INT,
    nombre VARCHAR(100),
    pais_nombre VARCHAR(100),
    PRIMARY KEY(codPostal)
);

CREATE TABLE IF NOT EXISTS Raza (
    codRaza INT,
    nombre VARCHAR(100),
    descripcion TEXT,
    PRIMARY KEY(codRaza)
);

CREATE TABLE IF NOT EXISTS Duenio (
    dni INT,
    nombre VARCHAR(100),
    apellido VARCHAR(100),
    direccion VARCHAR(200),
    PRIMARY KEY(dni)
);

CREATE TABLE IF NOT EXISTS Perro (
    codPerro INT,
    madre INT,
    raza INT,
    sexo BIT,
    nombre VARCHAR(100),
    fechaNacimiento DATE,
    PRIMARY KEY(codPerro)
);

CREATE TABLE IF NOT EXISTS DuenioxPerro (
    fechaInicio DATE,
    fechaFin DATE,
    duenio INT,
    perro INT,
    PRIMARY KEY(duenio, perro)
);

CREATE TABLE IF NOT EXISTS CruzexPadre (
    padre INT,
    perro INT,
    probabilidad DOUBLE,
    fecha DATE,
    PRIMARY KEY(padre, perro)
);

CREATE TABLE IF NOT EXISTS Concurso (
    codConcurso INT,
    mesAnio DATE,
    nombre VARCHAR(100),
    descripcion TEXT,
    ciudad_codPostal INT,
    PRIMARY KEY(codConcurso, mesAnio)
);

CREATE TABLE IF NOT EXISTS Inscripcion (
    codPerro INT,
    codConcurso INT,
    mesAnio DATE,
    calificacion INT,
    PRIMARY KEY(codPerro, codConcurso, mesAnio)
);

CREATE TABLE IF NOT EXISTS Calificacion (
    codPerro INT,
    codConcurso INT,
    PRIMARY KEY(codPerro, codConcurso)
);

ALTER TABLE Ciudad
    ADD CONSTRAINT fkciudad_pais FOREIGN KEY (pais_nombre) REFERENCES Pais(nombre);

ALTER TABLE Perro
    ADD CONSTRAINT fkperro_madre FOREIGN KEY (madre) REFERENCES Perro(codPerro),
    ADD CONSTRAINT fkperro_raza FOREIGN KEY (raza) REFERENCES Raza(codRaza);

ALTER TABLE DuenioxPerro
    ADD CONSTRAINT fkduenioxperro_duenio FOREIGN KEY (duenio) REFERENCES Duenio(dni),
    ADD CONSTRAINT fkduenioxperro_perro FOREIGN KEY (perro) REFERENCES Perro(codPerro);

ALTER TABLE CruzexPadre
    ADD CONSTRAINT fkcruzexpadre_padre FOREIGN KEY (padre) REFERENCES Perro(codPerro),
    ADD CONSTRAINT fkcruzexpadre_perro FOREIGN KEY (perro) REFERENCES Perro(codPerro);

ALTER TABLE Concurso
    ADD CONSTRAINT fkconcurso_ciudad FOREIGN KEY (ciudad_codPostal) REFERENCES Ciudad(codPostal);

ALTER TABLE Inscripcion
    ADD CONSTRAINT fkinscripcion_perro FOREIGN KEY (codPerro) REFERENCES Perro(codPerro),
    ADD CONSTRAINT fkinscripcion_concurso FOREIGN KEY (codConcurso, mesAnio) REFERENCES Concurso(codConcurso, mesAnio);

ALTER TABLE Calificacion
    ADD CONSTRAINT fkcalificacion_perro FOREIGN KEY (codPerro) REFERENCES Perro(codPerro),
    ADD CONSTRAINT fkcalificacion_concurso FOREIGN KEY (codConcurso) REFERENCES Concurso(codConcurso);