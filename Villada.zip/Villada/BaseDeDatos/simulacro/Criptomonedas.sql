CREATE DATABASE IF NOT EXISTS base_criptomonedas;

USE base_criptomonedas;

CREATE TABLE IF NOT EXISTS Pais (
    cod_pais INT AUTO_INCREMENT, 
    nombre VARCHAR(30), 
    CONSTRAINT pk_pais PRIMARY KEY (cod_pais)
); 

INSERT INTO Pais (nombre) VALUES ('Argentina');
INSERT INTO Pais (nombre) VALUES ('Estados Unidos');
INSERT INTO Pais (nombre) VALUES ('España');

CREATE TABLE IF NOT EXISTS Provincias (
    cod_provincia INT AUTO_INCREMENT, 
    nombre VARCHAR(30), 
    cod_pais INT,
    CONSTRAINT pk_provincias PRIMARY KEY (cod_provincia),
    CONSTRAINT fl_prov_pais FOREIGN KEY (cod_pais) REFERENCES Pais(cod_pais)
); 

INSERT INTO Provincias (nombre, cod_pais) VALUES ('Cordoba', 1);
INSERT INTO Provincias (nombre, cod_pais) VALUES ('Miami', 2);
INSERT INTO Provincias (nombre, cod_pais) VALUES ('Madrid', 3);

CREATE TABLE Documento (
    cod_documento NUMERIC,
    tipo_documento VARCHAR(10),
    numero_documento VARCHAR(50) UNIQUE,
    CONSTRAINT pk_documento PRIMARY KEY (cod_documento)
);

INSERT INTO Documento (cod_documento, tipo_documento, numero_documento) VALUES (1, 'DNI', '46784923');
INSERT INTO Documento (cod_documento, tipo_documento, numero_documento) VALUES (2, 'Passport', 'A3512435');

CREATE TABLE IF NOT EXISTS Ejecutivo (
    legajo INT AUTO_INCREMENT,
    nombre VARCHAR(50),
    apellido VARCHAR(50),
    id_coordinador INT,
    documento NUMERIC,
    CONSTRAINT pk_ejecutivo PRIMARY KEY (legajo),
    CONSTRAINT fl_eje_doc FOREIGN KEY (documento) REFERENCES Documento(cod_documento),
    CONSTRAINT fl_eje_coor FOREIGN KEY (id_coordinador) REFERENCES Ejecutivo(legajo)
);

INSERT INTO Ejecutivo (nombre, apellido, id_coordinador, documento) VALUES ('Pedro', 'Ramirez', NULL, 1);
INSERT INTO Ejecutivo (nombre, apellido, id_coordinador, documento) VALUES ('Juan', 'Circo', 1, 2);

CREATE TABLE IF NOT EXISTS Cliente (
    cod_cliente INT AUTO_INCREMENT,
    nombre VARCHAR(50),
    apellido VARCHAR(50),
    email VARCHAR(75),
    fecha_alta DATE,
    cod_provincia INT,
    CONSTRAINT pk_cliente PRIMARY KEY (cod_cliente),
    CONSTRAINT fl_cli_prov FOREIGN KEY (cod_provincia) REFERENCES Provincias(cod_provincia)
);

INSERT INTO Cliente (nombre, apellido, email, fecha_alta, cod_provincia) VALUES ('Mirtha', 'Sosa', 'mirtha@gmail.com', '1997-02-19', 1);
INSERT INTO Cliente (nombre, apellido, email, fecha_alta, cod_provincia) VALUES ('Edinson', 'Martinez', 'edimartinez@gmail.com', '2001-12-31', 2);

CREATE TABLE IF NOT EXISTS Telefono (
    cod_telefono INT AUTO_INCREMENT,
    numero NUMERIC,
    cod_cliente INT,
    CONSTRAINT pk_telefono PRIMARY KEY (cod_telefono),
    CONSTRAINT fl_tel_cli FOREIGN KEY (cod_cliente) REFERENCES Cliente(cod_cliente)
);

INSERT INTO Telefono (numero, cod_cliente) VALUES (3516873988, 1);
INSERT INTO Telefono (numero, cod_cliente) VALUES (3512846590, 2);

CREATE TABLE IF NOT EXISTS Criptomoneda (
    cod_cripto VARCHAR(3),
    nombre VARCHAR(50),
    CONSTRAINT pk_cripto PRIMARY KEY (cod_cripto)
);

INSERT INTO Criptomoneda (cod_cripto, nombre) VALUES ('BTC', 'Bitcoin');
INSERT INTO Criptomoneda (cod_cripto, nombre) VALUES ('ETH', 'Ethereum');
INSERT INTO Criptomoneda (cod_cripto, nombre) VALUES ('LTC', 'Litecoin');
INSERT INTO Criptomoneda (cod_cripto, nombre) VALUES ('USD', 'Dolar');
INSERT INTO Criptomoneda (cod_cripto, nombre) VALUES ('ARS', 'Peso Argentino');

CREATE TABLE IF NOT EXISTS CotizacionCripto (
    cod_cotizacion INT AUTO_INCREMENT,
    precio FLOAT,
    fecha_inicio DATETIME,
    fecha_fin DATETIME,
    cod_cripto VARCHAR(3),
    CONSTRAINT pk_cotizacion PRIMARY KEY (cod_cotizacion),
    CONSTRAINT fl_crip_coti FOREIGN KEY (cod_cripto) REFERENCES Criptomoneda(cod_cripto)
);

INSERT INTO CotizacionCripto (precio, fecha_inicio, fecha_fin, cod_cripto) VALUES (100000, '2024-08-15 00:00:00', '2024-08-15 23:59:59', 'BTC');
INSERT INTO CotizacionCripto (precio, fecha_inicio, fecha_fin, cod_cripto) VALUES (5000, '2024-08-15 00:00:00', '2024-08-15 23:59:59', 'ETH');
INSERT INTO CotizacionCripto (precio, fecha_inicio, fecha_fin, cod_cripto) VALUES (1000, '2024-08-15 00:00:00', '2024-08-15 23:59:59', 'LTC');
INSERT INTO CotizacionCripto (precio, fecha_inicio, fecha_fin, cod_cripto) VALUES (1, '2024-08-15 00:00:00', '2024-08-15 23:59:59', 'USD');
INSERT INTO CotizacionCripto (precio, fecha_inicio, fecha_fin, cod_cripto) VALUES (0.5, '2024-08-15 00:00:00', '2024-08-15 23:59:59', 'ARS');

CREATE TABLE IF NOT EXISTS Monedero (
    cod_monedero INT AUTO_INCREMENT,
    cod_cliente INT,
    cod_cripto VARCHAR(3),
    cant_cripto FLOAT,
    CONSTRAINT pk_monedero PRIMARY KEY (cod_monedero),
    CONSTRAINT fl_mon_crip FOREIGN KEY (cod_cripto) REFERENCES Criptomoneda(cod_cripto),
    CONSTRAINT fl_mon_cli FOREIGN KEY (cod_cliente) REFERENCES Cliente(cod_cliente)
);

INSERT INTO Monedero (cod_cliente, cod_cripto) VALUES (1, 'BTC');
INSERT INTO Monedero (cod_cliente, cod_cripto) VALUES (1, 'ETH');
INSERT INTO Monedero (cod_cliente, cod_cripto) VALUES (2, 'LTC');

CREATE TABLE IF NOT EXISTS Transaccion (
    cod_transaccion INT AUTO_INCREMENT,
    cod_cliente INT,
    fecha_transaccion DATETIME,
    legajo INT,
    CONSTRAINT pk_transaccion PRIMARY KEY (cod_transaccion),
    CONSTRAINT fl_trans_cli FOREIGN KEY (cod_cliente) REFERENCES Cliente(cod_cliente),
    CONSTRAINT fl_trans_ejec FOREIGN KEY (legajo) REFERENCES Ejecutivo(legajo)
);

INSERT INTO Transaccion (cod_cliente, fecha_transaccion, legajo) VALUES (1, '2024-08-14 19:21:35', 1);
INSERT INTO Transaccion (cod_cliente, fecha_transaccion, legajo) VALUES (2, '2024-08-15 17:40:10', 2);

CREATE TABLE IF NOT EXISTS Detalle_Transaccion (
    cod_detalle INT AUTO_INCREMENT,
    cod_transaccion INT,
    cod_cripto VARCHAR(3),
    tipo_operacion ENUM('Compra','Venta'),
    cantidad DECIMAL(20, 8),
    CONSTRAINT pk_detalle PRIMARY KEY (cod_detalle),
    CONSTRAINT fl_det_trans FOREIGN KEY (cod_transaccion) REFERENCES Transaccion(cod_transaccion),
    CONSTRAINT fl_det_cripto FOREIGN KEY (cod_cripto) REFERENCES Criptomoneda(cod_cripto)
);

INSERT INTO Detalle_Transaccion (cod_transaccion, cod_cripto, tipo_operacion, cantidad) VALUES (1, 'BTC', 'Compra', 0.5);
INSERT INTO Detalle_Transaccion (cod_transaccion, cod_cripto, tipo_operacion, cantidad) VALUES (1, 'ETH', 'Venta', 1.0);
INSERT INTO Detalle_Transaccion (cod_transaccion, cod_cripto, tipo_operacion, cantidad) VALUES (2, 'LTC', 'Compra', 10.0);

#1
select Cliente.cod_cliente, Cliente.nombre, Cliente.apellido, Pais.nombre as Pais, Provincias.nombre as Provincia, Cliente.fecha_alta from Cliente
INNER JOIN Provincias ON Cliente.cod_provincia = Provincias.cod_provincia
INNER JOIN Pais ON Provincias.cod_pais = Pais.cod_pais
INNER JOIN Monedero ON Cliente.cod_cliente = Monedero.cod_cliente
where Pais.nombre REGEXP '[AEIOUaeiou]' and Cliente.fecha_alta between '2024-05-01' and '2024-08-31'
GROUP BY Cliente.cod_cliente having count(Monedero.cod_monedero) > 2;

#2
SELECT Criptomoneda.cod_cripto, Criptomoneda.nombre, 
		COUNT(Detalle_Transaccion.cod_detalle) as Cantidad_movimientos, 
		SUM(Detalle_Transaccion.cantidad * CotizacionCripto.precio) as Cantidad_en_movimiento,
        MAX(Detalle_Transaccion.cantidad * CotizacionCripto.precio) as Monto_maximo,
        MIN(Detalle_Transaccion.cantidad * CotizacionCripto.precio) as Monto_minimo
FROM Criptomoneda
INNER JOIN Detalle_Transaccion on Criptomoneda.cod_cripto = Detalle_Transaccion.cod_cripto
INNER JOIN Transaccion on Detalle_Transaccion.cod_transaccion = Transaccion.cod_transaccion
INNER JOIN CotizacionCripto on Criptomoneda.cod_cripto = CotizacionCripto.cod_cripto
where (Transaccion.fecha_transaccion) = MONTH(CURDATE()) AND YEAR(Transaccion.fecha_transaccion) = YEAR(CURDATE())
GROUP BY Criptomoneda.cod_cripto, Criptomoneda.nombre
HAVING COUNT(Detalle_Transaccion.cod_detalle) > 2;

#3
UPDATE CotizacionCripto 
INNER JOIN Criptomoneda ON CotizacionCripto.cod_cripto = Criptomoneda.cod_cripto
SET 
    CotizacionCripto.precio = CotizacionCripto.precio * 1000,
    CotizacionCripto.fecha_inicio = NOW(),
    CotizacionCripto.fecha_fin = NOW()
WHERE Criptomoneda.cod_cripto IN ('BTC', 'ETH', 'LTC') AND Criptomoneda.cod_cripto NOT LIKE 'USD' AND Criptomoneda.cod_cripto NOT LIKE 'ARS';

SELECT * FROM CotizacionCripto;