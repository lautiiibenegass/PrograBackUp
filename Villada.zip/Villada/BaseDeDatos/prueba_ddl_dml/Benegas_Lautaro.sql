CREATE DATABASE IF NOT EXISTS Vengadores;
USE Vengadores;

CREATE TABLE IF NOT EXISTS Especie( 
    codEspecie INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(30),
    descripcion VARCHAR(255),
    CONSTRAINT pk_especie PRIMARY KEY (codEspecie)
);
CREATE TABLE IF NOT EXISTS Pais ( 
    codPais INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(30),
    descripcion VARCHAR(255),
    CONSTRAINT pk_pais PRIMARY KEY (codPais)
);
CREATE TABLE IF NOT EXISTS NacionalidadHumana ( 
    codNacionalidad INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(30),
    descripcion VARCHAR(255),
    CONSTRAINT pk_nacionalidad PRIMARY KEY (codNacionalidad)
);
CREATE TABLE IF NOT EXISTS EstadoHeroe ( 
    codEstadoHeroe INT  UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(30),
    descripcion VARCHAR(255),
    CONSTRAINT pk_estado_heroe PRIMARY KEY (codEstadoHeroe)
);
CREATE TABLE IF NOT EXISTS Rol ( 
    codRol INT UNSIGNED NOT NULL AUTO_INCREMENT,
    descripcion VARCHAR(255),
    nombre VARCHAR(30),
    CONSTRAINT pk_rol PRIMARY KEY (codRol)
);
CREATE TABLE IF NOT EXISTS PlanAccion ( 
    codPlan INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(30),
    descripcion VARCHAR(255),
    CONSTRAINT pk_plan_accion PRIMARY KEY (codPlan)
);
CREATE TABLE IF NOT EXISTS Habilidad ( 
    codHabilidad INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(30),
    descripcion VARCHAR(255),
    CONSTRAINT pk_habilidad PRIMARY KEY (codHabilidad)
);
CREATE TABLE IF NOT EXISTS Heroe ( 
    codHeroe INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre_real VARCHAR(30),
    alias VARCHAR(30),
    genero VARCHAR(1),
    altura FLOAT,
    fechaNacimiento DATE,
    especie INT UNSIGNED,
    nacionalidadHumana INT UNSIGNED,
    paisResidencia INT UNSIGNED,
    habilidad INT UNSIGNED,
    rol INT UNSIGNED,
    planAccion INT UNSIGNED,
    mail VARCHAR(30),
    estadoHeroe INT UNSIGNED,
    CONSTRAINT pk_heroe PRIMARY KEY (codHeroe),
    CONSTRAINT fk_especie FOREIGN KEY(especie) REFERENCES Especie(codEspecie),
    CONSTRAINT fk_nacionalidad_humana FOREIGN KEY(nacionalidadHumana) REFERENCES NacionalidadHumana(codNacionalidad),
    CONSTRAINT fk_pais_residencia FOREIGN KEY(paisResidencia) REFERENCES Pais(codPais),
    CONSTRAINT fk_plan_accion FOREIGN KEY(planAccion) REFERENCES PlanAccion(codPlan),
    CONSTRAINT fk_rol FOREIGN KEY(rol) REFERENCES Rol(codRol),
    CONSTRAINT fk_habilidad FOREIGN KEY(habilidad) REFERENCES Habilidad(codHabilidad),
    CONSTRAINT fk_estado_heroe FOREIGN KEY(estadoHeroe) REFERENCES EstadoHeroe(codEstadoHeroe)
);

CREATE TABLE IF NOT EXISTS OrgPolicial ( 
    codOrganismo INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(30),
    descripcion VARCHAR(255),
    CONSTRAINT pk_organismo_policial PRIMARY KEY (codOrganismo)
);
CREATE TABLE IF NOT EXISTS UsuarioPolicial ( 
    codUsuarioPolicial INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(30),
    descripcion VARCHAR(255),
    orgPolicial INT UNSIGNED,
    CONSTRAINT pk_usuario_policial PRIMARY KEY (codUsuarioPolicial),
    CONSTRAINT fk_organismo_policial FOREIGN KEY(orgPolicial) REFERENCES OrgPolicial(codOrganismo)
);
CREATE TABLE IF NOT EXISTS Criticidad ( 
    codCriticidad INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(30),
    descripcion VARCHAR(255),
    CONSTRAINT pk_criticidad PRIMARY KEY (codCriticidad)
);
CREATE TABLE IF NOT EXISTS TipoCaso ( 
    codTipoCaso INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(30),
    descripcion VARCHAR(255),
    CONSTRAINT pk_tipo_caso PRIMARY KEY (codTipoCaso)
);
CREATE TABLE IF NOT EXISTS EstadoCaso ( 
    codEstadoCaso INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(30),
    descripcion VARCHAR(255),
    CONSTRAINT pk_estado_caso PRIMARY KEY (codEstadoCaso)
);
CREATE TABLE IF NOT EXISTS Caso ( 
    codCaso INT UNSIGNED NOT NULL AUTO_INCREMENT,
    descripcion VARCHAR(255),
    criticidad INT UNSIGNED,
    latitudLongitud FLOAT,
    tipoCaso INT UNSIGNED,
    estadoCaso INT UNSIGNED,
    orgPolicial INT UNSIGNED,
    CONSTRAINT pk_caso PRIMARY KEY (codCaso),
    CONSTRAINT fk_criticidad FOREIGN KEY(criticidad) REFERENCES Criticidad(codCriticidad),
    CONSTRAINT fk_tipo_caso FOREIGN KEY(tipoCaso) REFERENCES TipoCaso(codTipoCaso),
    CONSTRAINT fk_organismo_policial_caso FOREIGN KEY(orgPolicial) REFERENCES OrgPolicial(codOrganismo),
    CONSTRAINT fk_estado_caso FOREIGN KEY(estadoCaso) REFERENCES EstadoCaso(codEstadoCaso)
);

CREATE TABLE IF NOT EXISTS TipoMision ( 
    codTipoMision INT  UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(30),
    descripcion VARCHAR(255),
    CONSTRAINT pk_tipo_mision PRIMARY KEY (codTipoMision)
);
CREATE TABLE IF NOT EXISTS Mision ( 
    codMision INT UNSIGNED NOT NULL AUTO_INCREMENT,
    objetivo VARCHAR(30),
    fechaEjecucionPlanificada DATE,
    tipoMision INT UNSIGNED,
    Heroe INT UNSIGNED,
    Caso INT UNSIGNED,
    CONSTRAINT pk_mision PRIMARY KEY (codMision),
    CONSTRAINT fk_tipo_mision FOREIGN KEY(tipoMision) REFERENCES TipoMision(codTipoMision),
    CONSTRAINT fk_heroe_mision FOREIGN KEY(Heroe) REFERENCES Heroe(codHeroe),
    CONSTRAINT fk_caso_mision FOREIGN KEY(Caso) REFERENCES Caso(codCaso)
);


#1
select *, Especie.codEspecie, Habilidad.codHabilidad from Heroe
inner join Especie on Heroe.especie = Especie.codEspecie
inner join Habilidad on Heroe.habilidad = Habilidad.codHabilidad
where (Heroe.especie != 1 and Heroe.especie != 2) and (Heroe.habilidad = 3 or Heroe.habilidad = 4);


#2
select Caso.*, EstadoCaso.codEstadoCaso from Caso
inner join EstadoCaso on Caso.estadoCaso = EstadoCaso.codEstadoCaso
where Caso.estadoCaso = 'Exitoso';


#3
select Misiones.*, Heroe.* from Heroe
inner join Heroe on Mision.codMision = Heroe.Mision
where Heroe.nacionalidadHumana = 'USA'

