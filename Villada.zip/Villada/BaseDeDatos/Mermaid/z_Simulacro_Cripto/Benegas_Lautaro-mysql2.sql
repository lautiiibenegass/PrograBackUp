create database if not exists cripto;
use cripto;

CREATE TABLE if not exists TipoTelefono ( 
    tipo varchar(30),
    descripcion varchar(30),
    PRIMARY KEY (tipo)
);
CREATE TABLE if not exists Pais ( 
    nombre varchar(30),
    descripcion varchar(30),
    PRIMARY KEY (nombre)
);
CREATE TABLE if not exists Ciudad ( 
    codCiudad INT,
    nombre VARCHAR(30),
    pais VARCHAR(30),
    descripcion VARCHAR(30),
    PRIMARY KEY (codCiudad),
    FOREIGN KEY (pais) REFERENCES Pais(nombre)
);

CREATE TABLE if not exists Cliente ( 
    numCliente INT,
    apellido varchar(30),
    nombre varchar(30),
    email varchar(30),
    telefono varchar(30),
    tipoTelefono varchar(30),
    ciudadResidencia int,
    paisResidencia varchar(30),
    fechaAlta DATE,
    constraint pk_cliente primary key (numCliente),
    CONSTRAINT fk_tipo_telefono FOREIGN KEY(tipoTelefono) REFERENCES TipoTelefono(tipo),
	CONSTRAINT fk_ciudad_residencia FOREIGN KEY(ciudadResidencia) REFERENCES Ciudad(codCiudad)
);