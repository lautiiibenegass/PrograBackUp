create database if not exists cripto;
use cripto;

CREATE TABLE if not exists HistorialCotizaciones ( 
    codigohist INT unsigned auto_increment,
    Criptomoneda varchar(30),
    cotizacion varchar(30),
    descripcion varchar(30),
    constraint pk_hist_cotizaciones PRIMARY KEY (codigohist)
);

CREATE TABLE if not exists Cotizacion ( 
    idCotizacion INT,
    valorDolares INT,
    hist_cotizacion int,
    dia DATE,
    hora time,
    constraint pk_cotizacion PRIMARY KEY (idCotizacion),
    constraint fk_historial_cotizaciones FOREIGN KEY(hist_cotizacion) REFERENCES HistorialCotizaciones(codigohist)
);

CREATE TABLE if not exists Criptomoneda ( 
    cod3Letras varchar(30),
    nombre varchar(30),
    Cotizaciones int,
    constraint pk_criptomoneda PRIMARY KEY (cod3Letras),
    constraint fk_cotizacion FOREIGN KEY(Cotizaciones) REFERENCES Cotizacion(idCotizacion)
);

CREATE TABLE if not exists TipoDocumento ( 
    tipo varchar(30),
    descripcion varchar(30),
    constraint pk_tipo_doc PRIMARY KEY (tipo)
);

CREATE TABLE if not exists TipoTelefono ( 
    tipo varchar(30),
    descripcion varchar(30),
    constraint pk_tipo_tel PRIMARY KEY (tipo)
);

CREATE TABLE if not exists Pais ( 
    nombre varchar(30),
    descripcion varchar(30),
    constraint pk_pais PRIMARY KEY (nombre)
);

CREATE TABLE if not exists Ciudad ( 
    codCiudad INT,
    nombre VARCHAR(30),
    pais VARCHAR(30),
    descripcion VARCHAR(30),
    constraint pk_ciudad PRIMARY KEY (codCiudad),
    constraint fk_pais FOREIGN KEY (pais) REFERENCES Pais(nombre)
);

CREATE TABLE if not exists Cliente ( 
    numCliente INT,
    apellido varchar(30),
    nombre varchar(30),
    email varchar(30),
    telefono varchar(30),
    tipoTelefono varchar(30),
    ciudadResidencia int,
    ejecutivo int,
    paisResidencia varchar(30),
    fechaAlta DATE,
    constraint pk_cliente primary key (numCliente),
    CONSTRAINT fk_tipo_telefono FOREIGN KEY(tipoTelefono) REFERENCES TipoTelefono(tipo),
	CONSTRAINT fk_ciudad_residencia FOREIGN KEY(ciudadResidencia) REFERENCES Ciudad(codCiudad),
    CONSTRAINT fk_ejecutivo FOREIGN KEY(ejecutivo) REFERENCES Ejecutivo(legajo)
);

CREATE TABLE if not exists Ejecutivo ( 
    legajo INT,
    nombres varchar(30),
    apellido varchar(30),
    numDoc INT,
    tipoDoc varchar(30),
    supervisor int,
    constraint pk_ejecutivo PRIMARY KEY (legajo),
    constraint fk_supervisor foreign key(supervisor) REFERENCES Ejecutivo(legajo),
    constraint fk_tipo_doc foreign key(tipoDoc) REFERENCES TipoDocumento(tipo)
);

CREATE TABLE if not exists Transaccion ( 
    numTransaccion INT,
    Cliente INT,
    fechaTransaccion DATE,
    ejecutivo int,
    Criptomoneda varchar(30),
    constraint pk_transaccion PRIMARY KEY (numTransaccion,Cliente),
    constraint fk_criptomoneda_transa FOREIGN KEY(Criptomoneda) REFERENCES Criptomoneda(cod3Letras),
    constraint fk_cliente_transaccion FOREIGN KEY(Cliente) REFERENCES Cliente(numCliente),
    constraint fk_ejecutivo FOREIGN KEY(ejecutivo) references Ejecutivo(legajo)
);

CREATE TABLE if not exists Monedero ( 
    idMonedero INT,
    cantCriptos INT,
    Criptomoneda varchar(30),
    Cliente int,
    constraint pk_monedero PRIMARY KEY (idMonedero),
    constraint fk_cripto FOREIGN KEY(Criptomoneda) REFERENCES Criptomoneda(cod3Letras),
    constraint fk_cliente_monedero FOREIGN KEY(Cliente) REFERENCES Cliente(numCliente)
);



#1
select Cliente.numCliente, Cliente.nombre, Cliente.apellido, Cliente.paisResidencia, Cliente.fechaAlta, count(Monedero.idMonedero) as cant_monedero
from Cliente
inner join Monedero on Cliente.numCliente = Monedero.Cliente
where Cliente.paisResidencia regexp '[AEIOUaeiou]'
and (month(Cliente.fechaAlta) = 5 or month(Cliente.fechaAlta) = 6 or month(Cliente.fechaAlta) = 7 or month(Cliente.fechaAlta) = 8)
group by Cliente.numCliente, Cliente.nombre, Cliente.apellido, Cliente.paisResidencia, Cliente.fechaAlta
having count(Monedero.idMonedero) >=2


#2

