# Informe sobre la API Reqres

## Índice

1. Descripción de la API
2. Puntos Finales y Funcionalidades
3. Capturas de Pantalla
4. Consumo de la API
5. Desarrollo de Proyecto en Python
6. Conclusiones
7. Bibliografía

## Descripción de la API

Reqres es una API de prueba que proporciona datos ficticios para realizar pruebas y desarrollar aplicaciones. Ofrece puntos finales para simular operaciones CRUD (Crear, Leer, Actualizar, Eliminar) en recursos de usuarios. La API no requiere autenticación para acceder a la mayoría de sus funcionalidades, lo que la hace ideal para propósitos de aprendizaje y desarrollo.

## Puntos Finales y Funcionalidades

1. **Consulta GET genérica:** Se puede obtener una lista de usuarios mediante una solicitud GET al endpoint `/api/users`. Esta consulta devuelve una lista de usuarios en formato JSON.

2. **Consultas POST y PUT:** Se pueden utilizar para crear nuevos usuarios (POST) y actualizar usuarios existentes (PUT). Los endpoints correspondientes son `/api/users` para crear usuarios y `/api/users/{id}` para actualizar usuarios por su ID.

3. **Consulta GET de búsqueda por ID:** Para obtener información sobre un usuario específico, se puede realizar una consulta GET al endpoint `/api/users/{id}`. Se reemplaza `{id}` con el ID del usuario deseado.

4. **Consulta de búsqueda utilizando claves distintas:** La API permite realizar consultas de búsqueda utilizando diferentes parámetros, como el nombre del usuario, el color de los ojos, la página, etc.

5. **Consulta de búsqueda lógica:** Por ejemplo, se puede buscar usuarios con un determinado color de ojos o una calificación superior a cierto valor.

## Capturas de Pantalla

adjunas en el archivo .zip

## Consumo de la API

Para probar los puntos finales de la API, se utiizo el cliente de interfaz "Thunder Client". Se pueden realizar solicitudes GET, POST, PUT y DELETE según sea necesario para probar las funcionalidades ofrecidas por la API.

## Desarrollo de Proyecto en Python

adjunto en el archivo .zip

## Conclusiones

La API Reqres proporciona una manera conveniente de practicar el consumo de APIs y el desarrollo de aplicaciones que interactúan con servicios web. Sus puntos finales simples y claros permiten realizar pruebas y experimentar con diferentes tipos de solicitudes HTTP. Además, al ser una API de prueba, no se necesita preocuparse por la autenticación o el acceso a datos sensibles, lo que la convierte en una excelente opción para propósitos de aprendizaje y desarrollo.

## Bibliografía

- Documentación oficial de Reqres: [https://reqres.in/](https://reqres.in/)
- Documentación de la biblioteca Requests para Python: [https://docs.python-requests.org/en/latest/](https://docs.python-requests.org/en/latest/)
- Documentación de la biblioteca pandas para Python: [https://pandas.pydata.org/docs/](https://pandas.pydata.org/docs/)

