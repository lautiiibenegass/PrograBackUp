import requests
import pandas as pd

# Función para obtener datos de la API Reqres
def get_users():
    url = 'https://reqres.in/api/users'
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()['data']
    else:
        print('Error al obtener los usuarios:', response.status_code)
        return None

# Función para mostrar los datos en forma de tabla
def display_users(users):
    if users:
        df = pd.DataFrame(users)
        print(df)
    else:
        print('No se pudieron obtener los usuarios.')

# Obtener y mostrar los usuarios
users = get_users()
display_users(users)