import requests

# Función para imprimir una línea punteada
def print_separator():
    print('-' * 50)

# Paso a: Generar una consulta GET genérica para obtener datos de la API
def get_users():
    print("Paso a: Generar una consulta GET genérica para obtener datos de la API")
    print_separator()
    url = 'https://reqres.in/api/users'
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()['data']
    else:
        print('Error al obtener los usuarios:', response.status_code)
        return None

# Paso b: Crear consultas POST y PUT para modificar datos en la API
def create_user(name, job):
    print("\nPaso b: Crear consultas POST y PUT para modificar datos en la API")
    print_separator()
    url = 'https://reqres.in/api/users'
    data = {'name': name, 'job': job}
    response = requests.post(url, json=data)
    if response.status_code == 201:
        return response.json()
    else:
        print('Error al crear el usuario:', response.status_code)
        return None

def update_user(user_id, name, job):
    url = f'https://reqres.in/api/users/{user_id}'
    data = {'name': name, 'job': job}
    response = requests.put(url, json=data)
    if response.status_code == 200:
        return response.json()
    else:
        print('Error al actualizar el usuario:', response.status_code)
        return None

# Paso c: Realizar una consulta GET de búsqueda utilizando parámetros de URL
def get_user_by_id(user_id):
    print("\nPaso c: Realizar una consulta GET de búsqueda utilizando parámetros de URL")
    print_separator()
    url = f'https://reqres.in/api/users/{user_id}'
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        print('Error al obtener el usuario:', response.status_code)
        return None

# Paso d: Realizar una consulta de búsqueda utilizando al menos dos claves de consulta distintas
def search_users_by_params(page=1, per_page=10):
    print("\nPaso d: Realizar una consulta de búsqueda utilizando al menos dos claves de consulta distintas")
    print_separator()
    url = f'https://reqres.in/api/users?page={page}&per_page={per_page}'
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()['data']
    else:
        print('Error al obtener los usuarios:', response.status_code)
        return None

# Paso e: Realizar una consulta de búsqueda lógica
def search_users_with_criteria(criteria):
    print("\nPaso e: Realizar una consulta de búsqueda lógica")
    print_separator()
    url = f'https://reqres.in/api/users?{criteria}'
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()['data']
    else:
        print('Error al realizar la búsqueda lógica:', response.status_code)
        return None

# Ejemplos de uso
# Paso a: Obtener usuarios
users = get_users()
print("Usuarios:", users)

# Paso b: Crear usuario
new_user = create_user('lautaro', 'student')
print("Nuevo usuario creado:", new_user)

# Paso c: Obtener usuario por ID
user_id = 2
user = get_user_by_id(user_id)
print("Usuario con ID", user_id, ":", user)

# Paso d: Buscar usuarios con parámetros de consulta distintos
page_number = 2
per_page_count = 5
users_filtered = search_users_by_params(page=page_number, per_page=per_page_count)
print(f"Usuarios en la página {page_number} con {per_page_count} usuarios por página:", users_filtered)

# Paso e: Buscar usuarios con criterios lógicos
criteria = 'name=lautaro&job=student'
users_with_criteria = search_users_with_criteria(criteria)
print("Usuarios que cumplen con los criterios:", users_with_criteria)
