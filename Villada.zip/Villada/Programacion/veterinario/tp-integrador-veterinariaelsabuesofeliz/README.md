### Integrantes:
- Bautista Barbero
- Franco Rosas
- Lautaro Benegas
- Juan Martin Picone

---

### Indice Github:
- [DIAGRAMAS E-R PNG](/Diagramas/Versiones)
- [DIAGRAMA E-R FINAL .mmd](/Diagramas/ERDiagram.mmd)
- [PROJECTO-DJANGO](/project)
  - [APP](/project/veterinaria)
  - [TEMPLATE](/project/templates)
  - [CONFIG](/project/config)
- [DIAGRAMA DE CLASES VERSIONES mmd](Diagrama%20de%20Clases/mermaid)
  - [VERSION 1 PNG](/Diagrama%20de%20Clases/V1.png)
