INSERT INTO veterinaria_tipodocumento (tipo, descripcion) VALUES 
('DNI', 'Documento Nacional de Identidad'),
('CUIL', 'Código Único de Identificación Laboral'),
('CUIT', 'Código Único de Identificación Tributaria'),
('LE', 'Libreta de Enrolamiento'),
('LC', 'Libreta Cívica');

INSERT INTO veterinaria_tipoempleado (matricula, descripcion) VALUES 
(1234, 'Veterinario'),
(2345, 'Asistente'),
(3456, 'Recepcionista'),
(4567, 'Auxiliar Veterinario'),
(5678, 'Administrativo');

INSERT INTO veterinaria_empleado (nro_documento, tipo_documento_id, fecha_ingreso, nombre, apellido, fecha_nacimiento, cargo, tipo_empleado_id) VALUES 
(30123456, 1, '2020-05-15', 'Juan', 'Pérez', '1990-04-25', 'Veterinario', 1),
(40123457, 2, '2021-06-10', 'Ana', 'Gómez', '1985-03-10', 'Asistente', 2),
(50123458, 3, '2019-07-20', 'Carlos', 'López', '1980-07-05', 'Recepcionista', 3),
(60123459, 1, '2018-08-30', 'Lucía', 'Martínez', '1992-11-15', 'Auxiliar', 4),
(70123460, 4, '2017-09-25', 'Sofía', 'Rodríguez', '1988-09-20', 'Administrativo', 5);

INSERT INTO veterinaria_sucursal (nombre, direccion) VALUES 
('Sucursal Central', 'Av. Principal 1234'),
('Sucursal Norte', 'Calle Secundaria 456'),
('Sucursal Este', 'Av. Tercera 789'),
('Sucursal Oeste', 'Calle Cuarta 1011'),
('Sucursal Sur', 'Calle Quinta 1213');

INSERT INTO veterinaria_raza (nombre_raza, peso_minimo_hembra, peso_maximo_hembra, altura_media_hembra, peso_minimo_macho, peso_maximo_macho, altura_media_macho, cuidados_especiales) VALUES 
('Labrador', 20.0, 30.0, 55.0, 25.0, 35.0, 60.0, 'Ejercicio diario y dieta balanceada'),
('Bulldog', 18.0, 23.0, 35.0, 20.0, 25.0, 40.0, 'Cuidados especiales para respiración y piel'),
('Pastor Alemán', 25.0, 32.0, 60.0, 30.0, 40.0, 65.0, 'Ejercicio y entrenamiento constante'),
('Beagle', 8.0, 14.0, 30.0, 10.0, 15.0, 35.0, 'Cuidado especial de orejas y ejercicio regular'),
('Poodle', 10.0, 15.0, 30.0, 12.0, 18.0, 35.0, 'Frecuente cepillado y corte de pelo');

INSERT INTO veterinaria_duenio (nombre_duenio, apellido_duenio, telefono_duenio) VALUES 
('María', 'Fernández', 34455),
('José', 'García', 34455),
('Laura', 'Ramírez', 34455),
('Pedro', 'Martínez', 34455),
('Ana', 'López', 34455),
('Carlos', 'González', 34455),
('Beatriz', 'Pérez', 34455),
('Sandra', 'Sánchez', 34455);

INSERT INTO veterinaria_perro (nro_hist_clinica, nombre_perro, fecha_nacimiento, raza_id, duenio_actual_id) VALUES 
(1001, 'Rex', '11-24-2023', 1, 1),
(1002, 'Luna', '11-24-2023', 2, 2),
(1003, 'Bobby', '11-24-2023', 3, 3),
(1004, 'Milo', '11-24-2023', 4, 4),
(1005, 'Nina', '11-24-2023', 5, 5);

INSERT INTO veterinaria_histduenio (duenio_id, perro_id, fecha_inicio, fecha_fin) VALUES 
(1, 1, '2021-04-15', NULL),
(2, 2, '2020-08-10', '2022-01-01'),
(3, 3, '2019-06-25', NULL),
(4, 4, '2022-01-30', NULL),
(5, 5, '2018-11-20', '2020-05-15');

INSERT INTO veterinaria_vacuna (nombre_vacuna, laboratorio) VALUES 
('Rabia', 'LabVet'),
('Parvovirus', 'VaxPet'),
('Moquillo', 'PetsCare'),
('Leptospirosis', 'CanBio'),
('Hepatitis', 'VaccineCorp');

INSERT INTO veterinaria_calendariovacuna (vacuna_id, fecha_estimada, fecha_vacunacion, empleado_id, dosis) VALUES 
(1, '2022-05-01', '2022-05-01', 1, 0.5),
(2, '2023-06-01', '2023-06-05', 2, 0.7),
(3, '2023-08-15', NULL, 3, 1.0),
(4, '2024-01-01', '2024-01-10', 4, 0.8),
(5, '2024-03-01', NULL, 5, 1.2);

INSERT INTO veterinaria_sintoma (nombre_sintoma, descripcion) VALUES 
('Tos', 'Tos seca y persistente'),
('Vómito', 'Vómito esporádico'),
('Fiebre', 'Aumento de temperatura'),
('Diarrea', 'Diarrea frecuente'),
('Letargo', 'Cansancio excesivo y letargo');

INSERT INTO veterinaria_medicamento (nombre_medicamento, fecha_ultima_compra, laboratorio, dosis) VALUES 
('Antiparasitario', '2023-02-01', 'BioVet', '5ml'),
('Antibiótico', '2023-05-01', 'MediVet', '10ml'),
('Vacuna Moquillo', '2024-06-01', 'VaxVet', '2ml'),
('Desinflamatorio', '2023-08-01', 'PetCare', '1ml'),
('Suero', '2024-09-01', 'LabPets', '50ml');

INSERT INTO veterinaria_receta (medicamento_id, periodicidad) VALUES 
(1, '1 day'),
(2, '12 hours'),
(3, '1 week'),
(4, '3 days'),
(5, '6 hours');

INSERT INTO veterinaria_estadoconsulta (cod_estado, estado, descripcion) VALUES 
(1, 'Pendiente', 'Consulta pendiente'),
(2, 'En proceso', 'Consulta en proceso'),
(3, 'Finalizada', 'Consulta finalizada'),
(4, 'Cancelada', 'Consulta cancelada por el cliente'),
(5, 'Reprogramada', 'Consulta reprogramada');

INSERT INTO veterinaria_consulta (fecha_entrada, fecha_salida, empleado_id, perro_id, sucursal_id, nro_consulta, peso_actual, altura_actual, diagnostico, estado_consulta_id) VALUES 
('2023-05-01', '2023-05-05', 1, 1, 1, 101, 25.0, 55.0, 'Infección leve', 1),
('2023-06-10', '2023-06-15', 2, 2, 2, 102, 23.0, 50.0, 'Gastroenteritis', 2),
('2023-07-20', '2023-07-25', 3, 3, 3, 103, 30.0, 60.0, 'Alergia', 3),
('2023-08-30', '2023-09-05', 4, 4, 4, 104, 20.0, 45.0, 'Infección de piel', 4),
('2023-09-25', '2023-10-01', 5, 5, 5, 105, 22.0, 48.0, 'Otitis', 5);

INSERT INTO veterinaria_historialconsulta (estado_consulta_id, fecha_inicio, fecha_fin, consulta_id) VALUES 
(1, '2023-05-01', '2023-05-05', 1),
(2, '2023-06-10', '2023-06-15', 2),
(3, '2023-07-20', '2023-07-25', 3),
(4, '2023-08-30', '2023-09-05', 4),
(5, '2023-09-25', '2023-10-01', 5);

INSERT INTO veterinaria_stock (cod_stock, medicamento_id, cant_stock, cant_min_sucursal, sucursal_id) VALUES 
(1001, 1, 50, 10, 1),
(1002, 2, 100, 15, 2),
(1003, 3, 200, 20, 3),
(1004, 4, 30, 5, 4),
(1005, 5, 150, 25, 5);
