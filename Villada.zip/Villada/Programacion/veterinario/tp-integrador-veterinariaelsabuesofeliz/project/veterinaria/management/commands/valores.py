from django.core.management.base import BaseCommand
from django.db import connection

class Command(BaseCommand):
    help = 'Carga datos en la base de datos desde un archivo .sql'

    def add_arguments(self, parser):
        parser.add_argument(
            'archivo_sql',
            type=str,
            help='Ruta del archivo .sql que se va a cargar en la base de datos'
        )

    def handle(self, *args, **options):
        archivo_sql = options['archivo_sql']
        try:
            with open(archivo_sql, 'r') as file:
                sql_script = file.read()

            with connection.cursor() as cursor:
                cursor.execute(sql_script)

            self.stdout.write(self.style.SUCCESS('Datos cargados exitosamente desde {}'.format(archivo_sql)))

        except FileNotFoundError:
            self.stdout.write(self.style.ERROR('Archivo no encontrado: {}'.format(archivo_sql)))
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error al cargar los datos: {e}'))
