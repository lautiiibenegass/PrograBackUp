from django.db import models
from django.utils import timezone
from datetime import date


class TipoDocumento(models.Model):
    tipo = models.CharField(max_length=50)
    descripcion = models.CharField(max_length=255)

    def __str__(self):
        return self.tipo

class TipoEmpleado(models.Model):
    matricula = models.IntegerField(null=True)
    descripcion = models.CharField(max_length=255)

    def __str__(self):
        return self.descripcion

class Empleado(models.Model):
    nro_documento = models.IntegerField()
    tipo_documento = models.ForeignKey(TipoDocumento, on_delete=models.CASCADE)
    fecha_ingreso = models.DateField()
    nombre = models.CharField(max_length=50)
    apellido = models.CharField(max_length=50)
    fecha_nacimiento = models.DateField()
    cargo = models.CharField(max_length=100)
    tipo_empleado = models.ForeignKey(TipoEmpleado, on_delete=models.CASCADE)

    def conocertipoempleado(self):
        return self.tipo_empleado.descripcion

    def conocertipodoc(self):
        return self.tipo_documento.tipo

    def calcularantiguedad(self):
        return (date.today() - self.fecha_ingreso).days // 365

    def __str__(self):
        return f"{self.nombre} {self.apellido}"

class Sucursal(models.Model):
    direccion = models.CharField(max_length=255)
    nombre = models.CharField(max_length=50)
    
    def __str__(self):
        return self.direccion

class Raza(models.Model):
    nombre_raza = models.CharField(max_length=100)
    peso_minimo_hembra = models.FloatField()
    peso_maximo_hembra = models.FloatField()
    altura_media_hembra = models.FloatField()
    peso_minimo_macho = models.FloatField()
    peso_maximo_macho = models.FloatField()
    altura_media_macho = models.FloatField()
    cuidados_especiales = models.TextField()

    def __str__(self):
        return self.nombre_raza

class Duenio(models.Model):
    nombre_duenio = models.CharField(max_length=100)
    apellido_duenio = models.CharField(max_length=100)
    telefono_duenio = models.IntegerField()

    def __str__(self):
        return f"{self.nombre_duenio} {self.apellido_duenio}"

class Perro(models.Model):
    nro_hist_clinica = models.IntegerField()
    nombre_perro = models.CharField(max_length=100)
    fecha_nacimiento = models.DateField()
    raza = models.ForeignKey(Raza, on_delete=models.CASCADE)
    duenio_actual = models.ForeignKey('Duenio', on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.nombre_perro
    
    def duenio(self):
        historial_actual = HistDuenio.objects.filter(perro=self, fecha_fin__isnull=True).first()
        return historial_actual.duenio if historial_actual else None

class HistDuenio(models.Model):
    duenio = models.ForeignKey(Duenio, on_delete=models.CASCADE)
    perro = models.ForeignKey(Perro, on_delete=models.CASCADE, related_name="historial_duenio", default=1)
    fecha_inicio = models.DateField()
    fecha_fin = models.DateField(blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.pk:
            historial_actual = HistDuenio.objects.filter(perro=self.perro, fecha_fin__isnull=True).first()
            if historial_actual:
                historial_actual.fecha_fin = timezone.now().date()
                historial_actual.save()

            self.fecha_inicio = timezone.now().date()

        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.fecha_inicio} {self.fecha_fin}"

class Vacuna(models.Model):
    nombre_vacuna = models.CharField(max_length=100)
    laboratorio = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre_vacuna

class CalendarioVacuna(models.Model):
    vacuna = models.ForeignKey(Vacuna, on_delete=models.CASCADE)
    fecha_estimada = models.DateField()
    fecha_vacunacion = models.DateField(blank=True, null=True)
    empleado = models.ForeignKey(Empleado, on_delete=models.CASCADE)
    dosis = models.FloatField()

    def __str__(self):
        return self.vacuna

class Sintoma(models.Model):
    nombre_sintoma = models.CharField(max_length=100)
    descripcion = models.TextField()

    def __str__(self):
        return self.nombre_sintoma

class Medicamento(models.Model):
    nombre_medicamento = models.CharField(max_length=100)
    fecha_ultima_compra = models.DateField()
    laboratorio = models.CharField(max_length=100)
    dosis = models.CharField(max_length=50)

    def __str__(self):
        return self.nombre_medicamento

class Receta(models.Model):
    medicamento = models.ForeignKey(Medicamento, on_delete=models.CASCADE)
    periodicidad = models.DurationField()

class EstadoConsulta(models.Model):
    cod_estado = models.IntegerField(null=True)
    estado = models.CharField(max_length=50)
    descripcion = models.TextField(null=True)
    
    def __str__(self):
        return self.estado
    
class Consulta(models.Model):
    fecha_entrada = models.DateField()
    fecha_salida = models.DateField()
    empleado = models.ForeignKey(Empleado, on_delete=models.CASCADE)
    perro = models.ForeignKey(Perro, on_delete=models.CASCADE)
    sucursal = models.ForeignKey(Sucursal, on_delete=models.CASCADE)
    nro_consulta = models.IntegerField()
    peso_actual = models.FloatField()
    altura_actual = models.FloatField()
    sintomas = models.ManyToManyField(Sintoma)
    diagnostico = models.CharField(max_length=100)
    receta = models.ManyToManyField(Receta)
    estado_consulta = models.ForeignKey(EstadoConsulta, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.sucursal} {self.nro_consulta}"

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        HistorialConsulta.objects.create(
            estado_consulta=self.estado_consulta,
            fecha_inicio=self.fecha_entrada,
            consulta=self
        )

class HistorialConsulta(models.Model):
    estado_consulta = models.ForeignKey(EstadoConsulta, on_delete=models.CASCADE)
    fecha_inicio = models.DateField()
    fecha_fin = models.DateField(blank=True, null=True)
    consulta = models.ForeignKey(Consulta, on_delete=models.CASCADE)

class Stock(models.Model):
    cod_stock = models.IntegerField()
    medicamento = models.ForeignKey(Medicamento, on_delete=models.CASCADE)
    cant_stock = models.IntegerField()
    cant_min_sucursal = models.IntegerField()
    sucursal = models.ForeignKey(Sucursal, on_delete=models.CASCADE)