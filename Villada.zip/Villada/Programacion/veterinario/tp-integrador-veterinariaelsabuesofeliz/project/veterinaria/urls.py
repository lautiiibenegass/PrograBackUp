from django.urls import path
from .views import MedicamentoCreateView, SintomaCreateView, EmpleadoDetailView, CambiarDuenioView, EmpleadoDeleteView, EmpleadoUpdateView,PerroUpdateView, PerroDeleteView, DuenioUpdateView, CalendarioCreateView, DuenioDeleteView, DuenioCreateView, PerroCreateView, SucursalCreateView, RazaCreateView, HomeView, exit, EmpleadoCreateView , ConsultaCreateView


urlpatterns = [
    # Paths de Duenio
    path('duenio/nuevo', DuenioCreateView.as_view(), name='duenioNuevo'),
    path('duenio/eliminar/<int:pk>/', DuenioDeleteView.as_view(), name='eliminar_duenio'),
    path('duenio/actualizar/<int:pk>/', DuenioUpdateView.as_view(), name='actualizar_duenio'),
    # Paths de Perro
    path('perro/nuevo', PerroCreateView.as_view(), name='perroNuevo'),
    path('perro/eliminar/<int:pk>/', PerroDeleteView.as_view(), name='eliminar_perro'),
    path('perro/actualizar/<int:pk>/', PerroUpdateView.as_view(), name='actualizar_perro'),
    path('cambiar/duenio/<int:perro_id>/', CambiarDuenioView.as_view(), name='cambiar_duenio'),

    # Paths de Empleado
    path('empleado/nueva', EmpleadoCreateView.as_view(), name='empleadoNuevo'),
    path('empleado/eliminar/<int:pk>/', EmpleadoDeleteView.as_view(), name='eliminar_empleado'),
    path('empleado/actualizar/<int:pk>/', EmpleadoUpdateView.as_view(), name='actualizar_empleado'),
    path('empleado/<int:pk>/', EmpleadoDetailView.as_view(), name='detail_empleado'),

    path('calendario/nuevo', CalendarioCreateView.as_view(), name='calendarioNuevo'),
    path('sucursal/nueva', SucursalCreateView.as_view(), name='sucursalNueva'),
    path('raza/nueva', RazaCreateView.as_view(), name='razaNueva'),
    path('consulta/nueva', ConsultaCreateView.as_view(), name='consultaNueva'),
    path('sintoma/nueva', SintomaCreateView.as_view(), name='sintomaNuevo'),
    path('medicamento/nueva', MedicamentoCreateView.as_view(), name='medicamentoNuevo'),
    
    
    path('', HomeView.as_view(), name='home'),
    path('logout', exit, name='exit')
]