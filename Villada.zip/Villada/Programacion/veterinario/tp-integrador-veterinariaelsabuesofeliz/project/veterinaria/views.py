from django.shortcuts import redirect
from django.urls import reverse_lazy
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.views.generic import TemplateView, View, DeleteView, UpdateView, DetailView, CreateView
from django.shortcuts import render, get_object_or_404
from .models import Medicamento, CalendarioVacuna, Perro, Duenio, Sucursal, Raza, Empleado, Consulta, HistDuenio, Sintoma
from .forms import MedicamentoForm, CalendarioVacunaForm, PerroForm, DuenioForm, SucursalForm, RazaForm, EmpleadoForm, ConsultaForm, CambiarDuenioForm, SintomaForm
from django.utils import timezone

# Valores Predefinidos
@method_decorator(login_required, name='dispatch')
class RazaCreateView(CreateView):
    model = Raza
    form_class = RazaForm
    template_name = 'veterinaria/valores-predefinidos/razaForm.html'
    success_url = reverse_lazy('razaNueva')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['razas'] = Raza.objects.all() 
        return context   

@method_decorator(login_required, name='dispatch')
class SintomaCreateView(CreateView):
    model = Sintoma
    form_class = SintomaForm
    template_name = 'veterinaria/valores-predefinidos/sintomaForm.html'
    success_url = reverse_lazy('sintomaNuevo')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['sintomas'] = Sintoma.objects.all() 
        return context

@method_decorator(login_required, name='dispatch')
class MedicamentoCreateView(CreateView):
    model = Medicamento
    form_class = MedicamentoForm
    template_name = 'veterinaria/valores-predefinidos/medicamentoForm.html'
    success_url = reverse_lazy('medicamentoNuevo')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['medicamentos'] = Medicamento.objects.all() 
        return context

@method_decorator(login_required, name='dispatch')
class SucursalCreateView(CreateView): 
    model = Sucursal
    form_class = SucursalForm
    template_name = 'veterinaria/sucursalForm.html'
    success_url = 'sucursalNueva'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['sucursales'] = Sucursal.objects.all() 
        return context

@method_decorator(login_required, name='dispatch')
class ConsultaCreateView(CreateView):
    model = Consulta
    form_class = ConsultaForm
    template_name = 'veterinaria/consultaForm.html'
    success_url = reverse_lazy('consultaNueva')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['consultas'] = Consulta.objects.all() 
        return context
    
@method_decorator(login_required, name='dispatch')
class CalendarioCreateView(CreateView):
    model = CalendarioVacuna
    form_class = CalendarioVacunaForm
    template_name = 'veterinaria/calendarioForm.html'
    success_url = reverse_lazy('calendarioNuevo')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['calendarios'] = CalendarioVacuna.objects.all() 
        return context

class HomeView(TemplateView):
    template_name = 'veterinaria/home.html'

def exit(request):
    logout(request)
    return redirect('home')

# Clases de Duenio
@method_decorator(login_required, name='dispatch')
class DuenioCreateView(CreateView):
    model = Duenio
    form_class = DuenioForm
    template_name = 'veterinaria/duenio/duenioForm.html'
    success_url = reverse_lazy('duenioNuevo')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['duenios'] = Duenio.objects.all() 
        return context

@method_decorator(login_required, name='dispatch')
class DuenioDeleteView(DeleteView):
    model = Duenio
    template_name = 'veterinaria/duenio/duenioDelete.html'
    success_url = reverse_lazy('duenioNuevo')

@method_decorator(login_required, name='dispatch')
class DuenioUpdateView(UpdateView):
    model = Duenio
    form_class = DuenioForm
    template_name = 'veterinaria/duenio/duenioUpdate.html'
    success_url = reverse_lazy('duenioNuevo')

# Clases de Perro
@method_decorator(login_required, name='dispatch')
class PerroCreateView(CreateView):
    model = Perro
    form_class = PerroForm
    template_name = 'veterinaria/perro/perroForm.html'
    success_url = reverse_lazy('perroNuevo')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['perros'] = Perro.objects.all() 
        return context
    
    def form_valid(self, form):
        response = super().form_valid(form)
        duenio_actual = form.instance.duenio_actual
        if duenio_actual:
            HistDuenio.objects.create(
                perro=form.instance,
                duenio=duenio_actual,
                fecha_inicio=timezone.now().date()
            )
        return response

@method_decorator(login_required, name='dispatch')
class PerroDeleteView(DeleteView):
    model = Perro
    template_name = 'veterinaria/perro/perroDelete.html'
    success_url = reverse_lazy('perroNuevo')

@method_decorator(login_required, name='dispatch')
class PerroUpdateView(UpdateView):
    model = Perro
    form_class = PerroForm
    template_name = 'veterinaria/perro/perroUpdate.html'
    success_url = reverse_lazy('perroNuevo')

@method_decorator(login_required, name='dispatch')
class CambiarDuenioView(View):
    def get(self, request, perro_id):
        perro = get_object_or_404(Perro, id=perro_id)
        form = CambiarDuenioForm(initial={'perro': perro})
        historial_duenios = HistDuenio.objects.filter(perro=perro).order_by('-fecha_inicio')
        return render(request, 'veterinaria/perro/perroCambiarDuenio.html', {
            'form': form,
            'perro': perro,
            'historial_duenios': historial_duenios
        })

    def post(self, request, perro_id):
        perro = get_object_or_404(Perro, id=perro_id)
        form = CambiarDuenioForm(request.POST)
        if form.is_valid():
            nuevo_duenio = form.cleaned_data['duenio']
            historial_actual = HistDuenio.objects.filter(perro=perro, fecha_fin__isnull=True).first()
            if historial_actual:
                historial_actual.fecha_fin = timezone.now().date()
                historial_actual.save()
            HistDuenio.objects.create(perro=perro, duenio=nuevo_duenio, fecha_inicio=timezone.now().date())
            return redirect('perroNuevo')  
        
        historial_duenios = HistDuenio.objects.filter(perro=perro).order_by('-fecha_inicio')
        return render(request, 'veterinaria/perro/perroCambiarDuenio.html', {
            'form': form,
            'perro': perro,
            'historial_duenios': historial_duenios
        })

# Clases de Empleado
@method_decorator(login_required, name='dispatch')
class EmpleadoCreateView(CreateView):
    model = Empleado
    form_class = EmpleadoForm
    template_name = 'veterinaria/empleado/empleadoForm.html'
    success_url = reverse_lazy('empleadoNuevo')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['empleados'] = Empleado.objects.all() 
        return context

@method_decorator(login_required, name='dispatch')
class EmpleadoDeleteView(DeleteView):
    model = Empleado
    template_name = 'veterinaria/empleado/empleadoDelete.html'
    success_url = reverse_lazy('empleadoNuevo')

@method_decorator(login_required, name='dispatch')
class EmpleadoUpdateView(UpdateView):
    model = Empleado
    form_class = EmpleadoForm
    template_name = 'veterinaria/empleado/empleadoUpdate.html'
    success_url = reverse_lazy('empleadoNuevo')

@method_decorator(login_required, name='dispatch')
class EmpleadoDetailView(DetailView):
    model = Empleado
    template_name = "veterinaria/empleado/empleadoDetail.html"
    context_object_name = "empleado"
