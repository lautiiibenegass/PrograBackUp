from django import forms
from .models import (
    TipoDocumento, TipoEmpleado, Empleado, Sucursal, Raza, Duenio, 
    HistDuenio, Perro, Vacuna, CalendarioVacuna, Sintoma, 
    Medicamento, Receta, Consulta, EstadoConsulta, HistorialConsulta, Stock
)

class TipoDocumentoForm(forms.ModelForm):
    class Meta:
        model = TipoDocumento
        fields = ['tipo', 'descripcion']
        widgets = {
            'nro_documento': forms.NumberInput(attrs={'class': 'form-control'}),
            'tipo': forms.TextInput(attrs={'class': 'form-control'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }

class TipoEmpleadoForm(forms.ModelForm):
    class Meta:
        model = TipoEmpleado
        fields = ['matricula', 'descripcion']
        widgets = {
            'matricula': forms.NumberInput(attrs={'class': 'form-control'}),
            'descripcion': forms.TextInput(attrs={'class': 'form-control'}),
        }

class EmpleadoForm(forms.ModelForm):
    class Meta:
        model = Empleado
        fields = ['nro_documento','tipo_documento', 'fecha_ingreso', 'nombre', 'apellido', 
                  'fecha_nacimiento', 'cargo', 'tipo_empleado']
        widgets = {
            'nro_documento': forms.NumberInput(attrs={'class': 'form-control'}),
            'tipo_documento': forms.Select(attrs={'class': 'form-select'}),
            'fecha_ingreso': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'apellido': forms.TextInput(attrs={'class': 'form-control'}),
            'fecha_nacimiento': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'cargo': forms.TextInput(attrs={'class': 'form-control'}),
            'tipo_empleado': forms.Select(attrs={'class': 'form-select'}),
        }


class SucursalForm(forms.ModelForm):
    class Meta:
        model = Sucursal
        fields = ['direccion', 'nombre']
        widgets = {
            'direccion': forms.TextInput(attrs={'class': 'form-control'}),
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
        }

class RazaForm(forms.ModelForm):
    class Meta:
        model = Raza
        fields = ['nombre_raza', 'peso_minimo_hembra', 'peso_maximo_hembra', 'altura_media_hembra',
                  'peso_minimo_macho', 'peso_maximo_macho', 'altura_media_macho', 'cuidados_especiales']
        widgets = {
            'nombre_raza': forms.TextInput(attrs={'class': 'form-control'}),
            'peso_minimo_hembra': forms.NumberInput(attrs={'class': 'form-control'}),
            'peso_maximo_hembra': forms.NumberInput(attrs={'class': 'form-control'}),
            'altura_media_hembra': forms.NumberInput(attrs={'class': 'form-control'}),
            'peso_minimo_macho': forms.NumberInput(attrs={'class': 'form-control'}),
            'peso_maximo_macho': forms.NumberInput(attrs={'class': 'form-control'}),
            'altura_media_macho': forms.NumberInput(attrs={'class': 'form-control'}),
            'cuidados_especiales': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }

class DuenioForm(forms.ModelForm):
    class Meta:
        model = Duenio
        fields = ['nombre_duenio', 'apellido_duenio', 'telefono_duenio']
        widgets = {
            'nombre_duenio': forms.TextInput(attrs={'class': 'form-control'}),
            'apellido_duenio': forms.TextInput(attrs={'class': 'form-control'}),
            'telefono_duenio': forms.NumberInput(attrs={'class': 'form-control'}),
        }

class HistDuenioForm(forms.ModelForm):
    class Meta:
        model = HistDuenio
        fields = ['duenio', 'perro']
        widgets = {
            'duenio': forms.Select(attrs={'class': 'form-select'}),
            'perro': forms.Select(attrs={'class': 'form-select'}),
        }

class CambiarDuenioForm(forms.Form):
    duenio = forms.ModelChoiceField(queryset=Duenio.objects.all(), label="Nuevo Dueño")

class PerroForm(forms.ModelForm):
    class Meta:
        model = Perro
        fields = ['nro_hist_clinica', 'nombre_perro', 'fecha_nacimiento', 'raza','duenio_actual']
        widgets = {
            'nro_hist_clinica': forms.NumberInput(attrs={'class': 'form-control'}),
            'nombre_perro': forms.TextInput(attrs={'class': 'form-control'}),
            'fecha_nacimiento': forms.DateInput(attrs={'type': 'date'}),
            'raza': forms.Select(attrs={'class': 'form-select'}),
            'duenio': forms.Select(attrs={'class': 'form-select'}),
        }

class VacunaForm(forms.ModelForm):
    class Meta:
        model = Vacuna
        fields = ['nombre_vacuna', 'laboratorio']
        widgets = {
            'nombre_vacuna': forms.TextInput(attrs={'class': 'form-control'}),
            'laboratorio': forms.TextInput(attrs={'class': 'form-control'}),
        }

class CalendarioVacunaForm(forms.ModelForm):
    class Meta:
        model = CalendarioVacuna
        fields = ['vacuna', 'fecha_estimada', 'fecha_vacunacion', 'empleado', 'dosis']
        widgets = {
            'vacuna': forms.Select(attrs={'class': 'form-select'}),
            'fecha_estimada': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'fecha_vacunacion': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'empleado': forms.Select(attrs={'class': 'form-select'}),
            'dosis': forms.NumberInput(attrs={'class': 'form-control'}),
        }

class SintomaForm(forms.ModelForm):
    class Meta:
        model = Sintoma
        fields = ['nombre_sintoma', 'descripcion']
        widgets = {
            'nombre_sintoma': forms.TextInput(attrs={'class': 'form-control'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }

class MedicamentoForm(forms.ModelForm):
    class Meta:
        model = Medicamento
        fields = ['nombre_medicamento', 'fecha_ultima_compra', 'laboratorio', 'dosis']
        widgets = {
            'nombre_medicamento': forms.TextInput(attrs={'class': 'form-control'}),
            'fecha_ultima_compra': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'laboratorio': forms.TextInput(attrs={'class': 'form-control'}),
            'dosis': forms.TextInput(attrs={'class': 'form-control'}),
        }

class RecetaForm(forms.ModelForm):
    class Meta:
        model = Receta
        fields = ['medicamento', 'periodicidad']
        widgets = {
            'medicamento': forms.Select(attrs={'class': 'form-select'}),
            'periodicidad': forms.TimeInput(attrs={'class': 'form-control', 'type': 'time'}),
        }

class ConsultaForm(forms.ModelForm):
    class Meta:
        model = Consulta
        fields = [
            'perro', 'sucursal', 'fecha_entrada', 'fecha_salida', 
            'empleado', 'nro_consulta', 'peso_actual', 
            'altura_actual', 'estado_consulta', 'sintomas', 
            'diagnostico', 'receta'
        ]
        widgets = {
            'perro': forms.Select(attrs={'class': 'form-select'}),
            'sucursal': forms.Select(attrs={'class': 'form-select'}),
            'fecha_entrada': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'fecha_salida': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'empleado': forms.Select(attrs={'class': 'form-select'}),
            'nro_consulta': forms.NumberInput(attrs={'class': 'form-control'}),
            'peso_actual': forms.NumberInput(attrs={'class': 'form-control'}),
            'altura_actual': forms.NumberInput(attrs={'class': 'form-control'}),
            'estado_consulta': forms.Select(attrs={'class': 'form-select'}),
            'sintomas': forms.SelectMultiple(attrs={'class': 'form-select'}),
            'diagnostico': forms.Textarea(),
            'receta': forms.SelectMultiple(attrs={'class': 'form-select'}),
        }

class EstadoConsultaForm(forms.ModelForm):
    class Meta:
        model = EstadoConsulta
        fields = ['cod_estado', 'estado', 'descripcion']
        widgets = {
            'cod_estado': forms.NumberInput(attrs={'class': 'form-control'}),
            'estado': forms.TextInput(attrs={'class': 'form-control'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }

class HistorialConsultaForm(forms.ModelForm):
    class Meta:
        model = HistorialConsulta
        fields = ['estado_consulta', 'fecha_inicio', 'fecha_fin', 'consulta']
        widgets = {
            'estado_consulta': forms.Select(attrs={'class': 'form-select'}),
            'fecha_inicio': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'fecha_fin': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'consulta': forms.Select(attrs={'class': 'form-select'}),
        }