const themeToggleBtn = document.getElementById('themeToggleBtn');
const themeIcon = document.getElementById('themeIcon');
    
    
if (localStorage.getItem('dark-mode') === 'true') {
    document.body.classList.add('dark-mode');
    themeIcon.src = "/static/img/moonIcon.png";  
    themeIcon.alt = 'Cambiar a modo claro';
} else {
    themeIcon.src = "/static/img/sunIcon.png";
    themeIcon.alt = 'Cambiar a modo oscuro';
}
    
themeToggleBtn.addEventListener('click', function() {
document.body.classList.toggle('dark-mode');
    
localStorage.setItem('dark-mode', document.body.classList.contains('dark-mode'));
    
if (document.body.classList.contains('dark-mode')) {
    themeIcon.src = "/static/img/moonIcon.png";
    themeIcon.alt = 'Cambiar a modo claro';
} else {
    themeIcon.src = "/static/img/sunIcon.png";
    themeIcon.alt = 'Cambiar a modo oscuro';
}
});