from django.contrib import admin
from django.urls import path, include
from polls.views import IndexView, ChatView, contextoView
from libreria.views import AutorCreateView, LibroCreateView, TablaView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('IndexView/', IndexView.as_view(), name='rankings'),
    path('inicio/', contextoView.as_view(), name='inicio'),
    path('ChatView/', ChatView.as_view(), name='netflix'),
    path('autor/nuevo/', AutorCreateView.as_view(), name='crear_autor'),
    path('libro/nuevo/', LibroCreateView.as_view(), name='crear_libro'),
    path('tabla/', TablaView.as_view(), name='tabla'),
]