from django.shortcuts import render

# Create your views here.
from django.views.generic import TemplateView, FormView
from django.urls import reverse
from .forms import AutorForm, LibroForm
from .models import Autor, Libro

class AutorCreateView(FormView):
    template_name = 'libreria/crear_autor.html'
    form_class = AutorForm

    def get_success_url(self):
        return reverse('tabla')
    
    def form_valid(self, form):
        form.save()  
        return super().form_valid(form)

class LibroCreateView(FormView):
    template_name = 'libreria/crear_libro.html'
    form_class = LibroForm
    
    def get_success_url(self):
        return reverse('tabla')
    
    def form_valid(self, form):
        form.save()
        return super().form_valid(form)

    def form_invalid(self, form):
        print(form.errors)
        return super().form_invalid(form)
    
class TablaView(TemplateView):
    template_name = 'libreria/tabla.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['autores'] = Autor.objects.all()
        context['libros'] = Libro.objects.all()
        return context